// WHMCS Elite CRM Pro - Content Script v3.0
// Gelişmiş Lisans ve Ödeme Yöntemi Çekme

(function() {
    'use strict';

    const currentUrl = window.location.href;
    console.log('[WHMCS Elite Content] Page:', currentUrl);

    // Services Page - Lisansları çek
    if (currentUrl.includes('action=services') || currentUrl.includes('clientarea.php')) {
        console.log('[WHMCS Elite] Services page detected');
        setTimeout(scrapeLicensesAdvanced, 3000);
    }

    // Payment Methods Page
    if (currentUrl.includes('paymentmethods')) {
        console.log('[WHMCS Elite] Payment page detected');
        setTimeout(scrapePaymentsAdvanced, 3000);
    }

    // ==================== GELİŞMİŞ LİSANS SCRAPER ====================

    function scrapeLicensesAdvanced() {
        chrome.storage.local.get(['current_bot_account'], (res) => {
            const email = res.current_bot_account;
            if (!email) return;

            const licenses = [];

            // Çoklu tablo seçicileri dene
            const tableSelectors = [
                '#tableServicesList',
                '#servicesTable',
                '.table-services',
                'table.table',
                'table',
                '.services-list table',
                '[class*="service" i] table'
            ];

            let table = null;
            for (const selector of tableSelectors) {
                try {
                    const el = document.querySelector(selector);
                    if (el && el.querySelectorAll('tr').length > 1) {
                        const text = el.innerText.toLowerCase();
                        if (text.includes('product') || text.includes('service') ||
                            text.includes('lisans') || text.includes('urun') ||
                            text.includes('status') || text.includes('durum')) {
                            table = el;
                            break;
                        }
                    }
                } catch (e) {}
            }

            if (!table) {
                console.log('[WHMCS Elite] No services table found');
                saveData(email, 'licenses', []);
                return;
            }

            const rows = table.querySelectorAll('tbody tr, tr');
            console.log(`[WHMCS Elite] Found ${rows.length} rows in table`);

            rows.forEach((row, index) => {
                const cells = row.querySelectorAll('td');
                if (cells.length < 3) return;

                try {
                    let product = '';
                    let licenseKey = '';
                    let billingCycle = '';
                    let dueDate = '';
                    let status = '';
                    let price = '';
                    let isActive = false;

                    // === ÜRÜN ADI ===
                    const productSelectors = [
                        'strong',
                        'a',
                        'h4',
                        'h3',
                        'h5',
                        '.product-name',
                        '[class*="product" i]'
                    ];

                    for (const sel of productSelectors) {
                        const el = row.querySelector(sel);
                        if (el) {
                            const text = el.innerText.trim();
                            if (text && text.length > 2 && text.toLowerCase() !== 'product') {
                                product = text;
                                break;
                            }
                        }
                    }

                    // Hücrelerden dene
                    if (!product && cells.length > 1) {
                        for (let i = 0; i < Math.min(cells.length, 3); i++) {
                            const text = cells[i].innerText.trim();
                            if (text && text.length > 2 && !text.includes('$') && !text.includes('€')) {
                                product = text.split('\n')[0];
                                break;
                            }
                        }
                    }

                    // === LİSANS KEY ===
                    // WHMCS lisans key formatları:
                    // WHMCS-ABC123, XXXX-XXXX-XXXX-XXXX, vb.

                    // 1. Önce spesifik elementleri dene
                    const keySelectors = [
                        'a[href*="license"]',
                        'code',
                        'pre',
                        '.license-key',
                        '[class*="key" i]'
                    ];

                    for (const sel of keySelectors) {
                        const el = row.querySelector(sel);
                        if (el) {
                            const text = el.innerText.trim();
                            if (text && (text.includes('-') || text.length > 8)) {
                                licenseKey = text;
                                break;
                            }
                        }
                    }

                    // 2. Tüm satırı tara - regex ile lisans key bul
                    if (!licenseKey) {
                        const rowText = row.innerText;
                        // WHMCS lisans key formatları
                        const patterns = [
                            /WHMCS-[A-Z0-9]+/i,                    // WHMCS-ABC123
                            /[A-Z0-9]{4,}-[A-Z0-9]{4,}-[A-Z0-9]{4,}/i,  // XXXX-XXXX-XXXX
                            /[A-Z0-9]{8,}/i,                        // 8+ karakter
                            /License[\s:]*([A-Z0-9-]+)/i,           // License: XXXX
                            /Key[\s:]*([A-Z0-9-]+)/i                // Key: XXXX
                        ];

                        for (const pattern of patterns) {
                            const match = rowText.match(pattern);
                            if (match) {
                                licenseKey = match[1] || match[0];
                                break;
                            }
                        }
                    }

                    // 3. Son hücreleri kontrol et (genelde son sütunlarda olur)
                    if (!licenseKey && cells.length > 3) {
                        for (let i = cells.length - 2; i < cells.length; i++) {
                            const text = cells[i].innerText.trim();
                            if (text && text.includes('-') && text.length > 5) {
                                licenseKey = text.split('\n')[0];
                                break;
                            }
                        }
                    }

                    // === FİYAT ===
                    for (let i = 0; i < cells.length; i++) {
                        const text = cells[i].innerText;
                        if (text.match(/[\$€£\d]/)) {
                            const lines = text.split('\n');
                            for (const line of lines) {
                                if (line.match(/[\$€£]/)) {
                                    price = line.trim();
                                    break;
                                }
                            }
                            if (price) break;
                        }
                    }

                    // === FATURA DÖNGÜSÜ ===
                    for (let i = 0; i < cells.length; i++) {
                        const text = cells[i].innerText.toLowerCase();
                        if (text.includes('monthly')) { billingCycle = 'Aylık'; break; }
                        if (text.includes('yearly') || text.includes('annually')) { billingCycle = 'Yıllık'; break; }
                        if (text.includes('one time')) { billingCycle = 'Tek Seferlik'; break; }
                        if (text.includes('free')) { billingCycle = 'Ücretsiz'; break; }
                    }

                    // === SON TARİH ===
                    for (let i = 0; i < cells.length; i++) {
                        const text = cells[i].innerText;
                        if (text.match(/\d{2}[\/\-\.]\d{2}[\/\-\.]\d{4}/) ||
                            text.match(/\d{4}[\/\-\.]\d{2}[\/\-\.]\d{2}/)) {
                            dueDate = text.split('\n')[0].trim();
                            break;
                        }
                    }

                    // === DURUM ===
                    const statusSelectors = ['.label', '.badge', '.status', 'td:last-child', 'td:nth-last-child(2)'];
                    for (const sel of statusSelectors) {
                        const el = row.querySelector(sel);
                        if (el) {
                            const text = el.innerText.trim();
                            if (text && (text.toLowerCase().includes('active') ||
                                         text.toLowerCase().includes('suspended') ||
                                         text.toLowerCase().includes('pending') ||
                                         text.toLowerCase().includes('cancelled') ||
                                         text.toLowerCase().includes('terminated'))) {
                                status = text;
                                break;
                            }
                        }
                    }

                    // === DURUM TÜRKÇELEŞTİRME ===
                    let statusTR = status;
                    const statusLower = status.toLowerCase();

                    if (statusLower.includes('active')) {
                        statusTR = 'Aktif';
                        isActive = true;
                    } else if (statusLower.includes('suspended')) {
                        statusTR = 'Askıya Alındı';
                    } else if (statusLower.includes('terminated')) {
                        statusTR = 'Sonlandırıldı';
                    } else if (statusLower.includes('cancelled')) {
                        statusTR = 'İptal Edildi';
                    } else if (statusLower.includes('pending')) {
                        statusTR = 'Beklemede';
                    } else if (statusLower.includes('fraud')) {
                        statusTR = 'Dolandırıcılık';
                    } else if (statusLower.includes('completed')) {
                        statusTR = 'Tamamlandı';
                    }

                    // Ürün adı varsa ve geçerliyse ekle
                    if (product && product.length > 2 &&
                        product.toLowerCase() !== 'product' &&
                        product.toLowerCase() !== 'urun' &&
                        product.toLowerCase() !== 'ürün' &&
                        !product.includes('$')) {

                        licenses.push({
                            product,
                            licenseKey: licenseKey || '',
                            price: price || '',
                            billingCycle: billingCycle || '',
                            dueDate: dueDate || '',
                            status: statusTR,
                            statusEN: status,
                            isActive
                        });

                        console.log(`[WHMCS Elite] License found: ${product} - Key: ${licenseKey || 'N/A'}`);
                    }
                } catch (e) {
                    console.log('[WHMCS Elite] Error processing row:', e);
                }
            });

            console.log(`[WHMCS Elite] Total licenses found: ${licenses.length}`);
            saveData(email, 'licenses', licenses);
        });
    }

    // ==================== GELİŞMİŞ ÖDEME SCRAPER ====================

    function scrapePaymentsAdvanced() {
        chrome.storage.local.get(['current_bot_account'], (res) => {
            const email = res.current_bot_account;
            if (!email) return;

            const payments = [];

            const tableSelectors = [
                '#payMethodList',
                '.table-payment-methods',
                'table',
                '[class*="payment" i] table'
            ];

            let table = null;
            for (const selector of tableSelectors) {
                try {
                    const el = document.querySelector(selector);
                    if (el && el.innerText.toLowerCase().includes('payment')) {
                        table = el;
                        break;
                    }
                } catch (e) {}
            }

            if (!table) {
                const alerts = document.querySelectorAll('.alert, .alert-info');
                for (const alert of alerts) {
                    if (alert.innerText.toLowerCase().includes('no payment') ||
                        alert.innerText.toLowerCase().includes('payment method')) {
                        saveData(email, 'payments', []);
                        return;
                    }
                }
                saveData(email, 'payments', []);
                return;
            }

            const rows = table.querySelectorAll('tbody tr, tr');

            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length < 3) return;

                try {
                    let methodName = '';
                    let description = '';
                    let status = '';
                    let isDefault = false;
                    let isActive = false;

                    // Yöntem adı
                    const nameSelectors = ['strong', 'b', 'td:nth-child(2)'];
                    for (const sel of nameSelectors) {
                        const el = row.querySelector(sel);
                        if (el) {
                            const text = el.innerText.trim();
                            if (text && text.toLowerCase() !== 'name') {
                                methodName = text;
                                break;
                            }
                        }
                    }

                    // Açıklama
                    const descEl = cells[2];
                    if (descEl) description = descEl.innerText.trim();

                    // Durum
                    const statusSelectors = ['.label', '.badge', 'td:nth-last-child(2)'];
                    for (const sel of statusSelectors) {
                        const el = row.querySelector(sel);
                        if (el) {
                            const text = el.innerText.trim();
                            if (text && (text.toLowerCase().includes('active') || text.toLowerCase().includes('inactive'))) {
                                status = text;
                                break;
                            }
                        }
                    }

                    // Varsayılan mı?
                    if (row.innerText.toLowerCase().includes('default') ||
                        row.innerText.toLowerCase().includes('varsayılan')) {
                        isDefault = true;
                    }

                    // Durum Türkçeleştirme
                    let statusTR = status;
                    const statusLower = status.toLowerCase();

                    if (statusLower.includes('active')) {
                        statusTR = 'Aktif';
                        isActive = true;
                    } else if (statusLower.includes('inactive')) {
                        statusTR = 'Pasif';
                    }

                    if (methodName && methodName.toLowerCase() !== 'name' && methodName.length > 1) {
                        payments.push({
                            methodName,
                            description,
                            status: statusTR,
                            statusEN: status,
                            isDefault,
                            isActive
                        });
                    }
                } catch (e) {}
            });

            console.log(`[WHMCS Elite] Found ${payments.length} payments`);
            saveData(email, 'payments', payments);
        });
    }

    // Save data
    function saveData(email, type, data) {
        chrome.storage.local.get(['accounts'], (res) => {
            const accounts = res.accounts || {};

            if (accounts[email]) {
                accounts[email][type] = data;
                accounts[email].last_updated = new Date().toISOString();

                chrome.storage.local.set({ accounts }, () => {
                    console.log(`[WHMCS Elite] Saved ${data.length} ${type} for ${email}`);
                });
            }
        });
    }

})();
