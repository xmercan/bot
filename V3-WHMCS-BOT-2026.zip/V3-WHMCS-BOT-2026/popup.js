// WHMCS Elite CRM Pro - Popup Script v3.0
// Tema desteği ve hızlı erişim

document.addEventListener('DOMContentLoaded', () => {
    loadTheme();
    loadStats();

    // Event listeners
    document.getElementById('openDashboard').addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
    });

    document.getElementById('quickBot').addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'QUICK_BOT_CHECK' });
        showNotification('Bot başlatıldı!');
    });

    document.getElementById('themeToggle').addEventListener('click', toggleTheme);

    document.getElementById('quickActiveLicenses').addEventListener('click', () => {
        chrome.tabs.create({
            url: chrome.runtime.getURL('dashboard.html') + '?tab=active-licenses'
        });
    });

    document.getElementById('quickProducts').addEventListener('click', () => {
        chrome.tabs.create({
            url: chrome.runtime.getURL('dashboard.html') + '?tab=licenses'
        });
    });
});

// Theme Management
function loadTheme() {
    const savedTheme = localStorage.getItem('whmcs-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('whmcs-theme', newTheme);
    updateThemeIcon(newTheme);
}

function updateThemeIcon(theme) {
    const icon = document.getElementById('themeIcon');
    if (icon) {
        icon.textContent = theme === 'dark' ? '☀️' : '🌙';
    }
}

function loadStats() {
    chrome.storage.local.get(['successfulLogins', 'failedLogins', 'accounts'], (res) => {
        const successful = res.successfulLogins || [];
        const failed = res.failedLogins || [];
        const accounts = res.accounts || {};

        let totalLicenses = 0;
        let totalPayments = 0;
        let activeLicenses = 0;

        Object.values(accounts).forEach(acc => {
            if (acc.licenses) {
                totalLicenses += acc.licenses.length;
                activeLicenses += acc.licenses.filter(l => l.isActive).length;
            }
            if (acc.payments) totalPayments += acc.payments.length;
        });

        document.getElementById('statSuccessful').textContent = successful.length;
        document.getElementById('statFailed').textContent = failed.length;
        document.getElementById('statLicenses').textContent = activeLicenses;
        document.getElementById('statPayments').textContent = totalPayments;
    });
}

function showNotification(message) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        bottom: 16px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--bg-card);
        color: var(--neon-green);
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid var(--neon-green);
        z-index: 1000;
    `;
    notif.textContent = message;
    document.body.appendChild(notif);

    setTimeout(() => notif.remove(), 2000);
}
