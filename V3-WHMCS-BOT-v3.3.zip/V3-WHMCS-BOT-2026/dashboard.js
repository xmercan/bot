// WHMCS Elite CRM Pro - Dashboard Script v3.3
// Düzeltilmiş: Manuel Devam Butonu, Sabit Bot Paneli

let accounts = {};
let successfulLogins = [];
let failedLogins = [];
let currentTab = 'active-licenses';
let currentProductFilter = null;
let sortColumn = null;
let sortDirection = 'asc';
let searchQuery = '';
let botStartTime = null;
let botProcessedCount = 0;
let isSkippingExisting = true;
let isWaitingForCaptcha = false;

// Audio Context for sound effects
let audioContext = null;

// Initialize Audio Context
function initAudio() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
}

// iPhone-style notification sound - SADECE AKTİF LİSANS İÇİN
function playSuccessSound() {
    initAudio();
    if (!audioContext) return;

    const now = audioContext.currentTime;

    const oscillator1 = audioContext.createOscillator();
    const oscillator2 = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator1.connect(gainNode);
    oscillator2.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator1.type = 'sine';
    oscillator1.frequency.setValueAtTime(880, now);
    oscillator1.frequency.exponentialRampToValueAtTime(440, now + 0.1);

    oscillator2.type = 'sine';
    oscillator2.frequency.setValueAtTime(1109, now);
    oscillator2.frequency.exponentialRampToValueAtTime(554, now + 0.1);

    gainNode.gain.setValueAtTime(0.3, now);
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.3);

    oscillator1.start(now);
    oscillator2.start(now);
    oscillator1.stop(now + 0.3);
    oscillator2.stop(now + 0.3);
}

// Cloudflare uyarı sesi - "Dıt dıt dıt"
function playCaptchaAlertSound() {
    initAudio();
    if (!audioContext) return;

    const now = audioContext.currentTime;
    
    for (let i = 0; i < 3; i++) {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(1200, now + (i * 0.4));
        
        gainNode.gain.setValueAtTime(0.5, now + (i * 0.4));
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + (i * 0.4) + 0.15);
        
        oscillator.start(now + (i * 0.4));
        oscillator.stop(now + (i * 0.4) + 0.15);
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadTheme();
    loadData();
    setupEventListeners();
    setupMessageListener();
    setupTabs();
    setupSorting();
    setupStatCards();
    setupMobileMenu();
    checkBotStatus(); // Bot durumunu kontrol et

    const urlParams = new URLSearchParams(window.location.search);
    const initialTab = urlParams.get('tab');
    if (initialTab) {
        const tabBtn = document.querySelector(`.tab[data-tab="${initialTab}"]`);
        if (tabBtn) tabBtn.click();
    }
});

// Bot durumunu kontrol et
async function checkBotStatus() {
    try {
        const response = await chrome.runtime.sendMessage({ type: 'GET_BOT_STATUS' });
        if (response && response.status) {
            // Bot çalışıyorsa paneli göster
            if (response.status.running) {
                document.getElementById('botPanel').classList.add('active');
                botStartTime = Date.now();
                startElapsedTimer();
            }
            
            // CAPTCHA bekleniyorsa uyarı göster
            if (response.status.waitingForCaptcha) {
                showCaptchaPanel(response.status.currentEmail);
            }
        }
    } catch (e) {}
}

// Theme Management
function loadTheme() {
    const savedTheme = localStorage.getItem('whmcs-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('whmcs-theme', newTheme);
    updateThemeIcon(newTheme);
}

function updateThemeIcon(theme) {
    const icon = document.getElementById('themeIcon');
    if (icon) {
        icon.textContent = theme === 'dark' ? '☀️' : '🌙';
    }
}

// Mobile Menu
function setupMobileMenu() {
    const toggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    toggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
    });

    overlay.addEventListener('click', () => {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
    });
}

// Load Data
function loadData() {
    chrome.storage.local.get(['accounts', 'successfulLogins', 'failedLogins', 'botRunning'], (res) => {
        accounts = res.accounts || {};
        successfulLogins = res.successfulLogins || [];
        failedLogins = res.failedLogins || [];
        
        // Bot çalışıyorsa paneli göster
        if (res.botRunning) {
            document.getElementById('botPanel').classList.add('active');
        }
        
        renderAll();
    });
}

// Setup Event Listeners
function setupEventListeners() {
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);

    document.getElementById('btnStartBot').addEventListener('click', showBotModal);
    document.getElementById('closeBotModal').addEventListener('click', hideBotModal);
    document.getElementById('cancelBot').addEventListener('click', hideBotModal);
    document.getElementById('confirmStartBot').addEventListener('click', startBot);

    const skipToggle = document.getElementById('skipExistingToggle');
    if (skipToggle) {
        skipToggle.addEventListener('change', (e) => {
            isSkippingExisting = e.target.checked;
        });
    }

    document.getElementById('btnImportTxt').addEventListener('click', () => {
        document.getElementById('fileImportTxt').click();
    });
    document.getElementById('fileImportTxt').addEventListener('change', handleTxtImport);

    document.getElementById('btnExportExcel').addEventListener('click', exportToExcel);
    document.getElementById('btnExportJson').addEventListener('click', exportToJson);
    document.getElementById('btnImportJson').addEventListener('click', () => {
        document.getElementById('fileImportJson').click();
    });
    document.getElementById('fileImportJson').addEventListener('change', handleJsonImport);
    document.getElementById('btnReset').addEventListener('click', resetAll);

    document.getElementById('btnPause').addEventListener('click', pauseBot);
    document.getElementById('btnResume').addEventListener('click', resumeBot);
    document.getElementById('btnStop').addEventListener('click', stopBot);
    document.getElementById('btnRestart').addEventListener('click', restartBot);

    document.getElementById('searchBox').addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase().trim();
        renderAll();
    });
    
    // Manuel devam et butonu
    const manualContinueBtn = document.getElementById('btnManualContinue');
    if (manualContinueBtn) {
        manualContinueBtn.addEventListener('click', manualContinue);
    }
}

// Manuel devam et
function manualContinue() {
    log('👤 Manuel devam et butonuna basıldı');
    
    // Background script'e bildir
    chrome.runtime.sendMessage({ type: 'CAPTCHA_MANUAL_CONTINUE' });
    
    // CAPTCHA panelini gizle
    hideCaptchaPanel();
    
    showNotification('✅ Manuel devam işlemi gönderildi!', 'success');
}

// Setup Tabs
function setupTabs() {
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;

            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

            tab.classList.add('active');
            const tabId = 'tab-' + tabName;
            const tabContent = document.getElementById(tabId);
            if (tabContent) {
                tabContent.classList.add('active');
            }

            currentTab = tabName;
            currentProductFilter = null;

            const submenu = document.getElementById('productSubmenu');
            if (tabName === 'licenses') {
                submenu.classList.add('active');
            } else {
                submenu.classList.remove('active');
            }

            renderAll();
        });
    });
}

// Setup Sorting
function setupSorting() {
    document.querySelectorAll('.data-table th[data-sort]').forEach(th => {
        th.addEventListener('click', () => {
            const column = th.dataset.sort;

            if (sortColumn === column) {
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                sortColumn = column;
                sortDirection = 'asc';
            }

            document.querySelectorAll('.data-table th').forEach(header => {
                header.classList.remove('sort-asc', 'sort-desc');
            });
            th.classList.add(sortDirection === 'asc' ? 'sort-asc' : 'sort-desc');

            renderAll();
        });
    });
}

// Setup Stat Cards
function setupStatCards() {
    document.querySelectorAll('.stat-card').forEach(card => {
        card.addEventListener('click', () => {
            const filter = card.dataset.filter;
            document.querySelectorAll('.stat-card').forEach(c => c.classList.remove('active'));
            card.classList.add('active');

            let targetTab = filter;
            if (filter === 'active-licenses') targetTab = 'active-licenses';
            else if (filter === 'all') targetTab = 'active-licenses';

            const tabButton = document.querySelector(`.tab[data-tab="${targetTab}"]`);
            if (tabButton) {
                tabButton.click();
            }
        });
    });
}

// Setup Message Listener
function setupMessageListener() {
    chrome.runtime.onMessage.addListener((msg) => {
        switch (msg.type) {
            case 'LOG':
                addBotLog(msg.message);
                break;
            case 'STATUS_UPDATE':
                updateBotStatus(msg);
                break;
            case 'BOT_STARTED':
                // Bot başlatıldığında paneli göster
                document.getElementById('botPanel').classList.add('active');
                document.getElementById('botPanel').style.display = 'block';
                botStartTime = Date.now();
                startElapsedTimer();
                break;
            case 'BOT_FINISHED':
                botFinished(msg);
                break;
            case 'BOT_STOPPED':
                document.getElementById('botPanel').classList.remove('active');
                botStartTime = null;
                break;
            case 'BOT_PAUSED':
            case 'BOT_RESUMED':
                loadData();
                break;
            case 'ACTIVE_LICENSE_FOUND':
                playSuccessSound();
                showNotification(`🎵 ${msg.activeCount || msg.count} adet AKTİF lisans bulundu!`, 'success');
                break;
            case 'CAPTCHA_REQUIRED':
                isWaitingForCaptcha = true;
                playCaptchaAlertSound();
                showCaptchaPanel(msg.email);
                break;
            case 'CAPTCHA_SOLVED':
                isWaitingForCaptcha = false;
                hideCaptchaPanel();
                break;
            case 'CAPTCHA_MANUAL_PRESSED':
                log('✅ Manuel devam işlemi alındı');
                break;
        }
    });
}

// CAPTCHA panelini göster
function showCaptchaPanel(email) {
    const captchaPanel = document.getElementById('captchaPanel');
    const captchaEmail = document.getElementById('captchaEmail');
    
    if (captchaPanel) {
        captchaPanel.style.display = 'block';
        captchaPanel.classList.add('active');
    }
    
    if (captchaEmail) {
        captchaEmail.textContent = email || 'Bilinmiyor';
    }
    
    // Ses çalmaya devam et
    const alertInterval = setInterval(() => {
        if (!isWaitingForCaptcha) {
            clearInterval(alertInterval);
        } else {
            playCaptchaAlertSound();
        }
    }, 3000);
}

// CAPTCHA panelini gizle
function hideCaptchaPanel() {
    const captchaPanel = document.getElementById('captchaPanel');
    if (captchaPanel) {
        captchaPanel.style.display = 'none';
        captchaPanel.classList.remove('active');
    }
}

// Render All
function renderAll() {
    renderStats();
    renderProductCards();
    renderProductSubmenu();
    renderActiveLicenses();
    renderSuccessful();
    renderFailed();
    renderLicenses();
    renderPayments();
}

// Get Account Password
function getAccountPassword(email) {
    const account = accounts[email];
    if (account && account.password) {
        return account.password;
    }
    const login = successfulLogins.find(l => l.email === email);
    if (login && login.password) {
        return login.password;
    }
    return '-';
}

// Global Search Filter
function matchesSearch(item, query) {
    if (!query) return true;

    const searchFields = [];
    if (item.email) searchFields.push(item.email.toLowerCase());
    if (item.password) searchFields.push(item.password.toLowerCase());
    if (item.product) searchFields.push(item.product.toLowerCase());
    if (item.licenseKey) searchFields.push(item.licenseKey.toLowerCase());
    if (item.methodName) searchFields.push(item.methodName.toLowerCase());
    if (item.description) searchFields.push(item.description.toLowerCase());
    if (item.status) searchFields.push(item.status.toLowerCase());
    if (item.error) searchFields.push(item.error.toLowerCase());
    if (item.price) searchFields.push(item.price.toLowerCase());
    if (item.billingCycle) searchFields.push(item.billingCycle.toLowerCase());
    if (item.cardType) searchFields.push(item.cardType.toLowerCase());

    return searchFields.some(field => field.includes(query));
}

// Sort Data
function sortData(data, column, direction) {
    if (!column) return data;
    return [...data].sort((a, b) => {
        let valA = a[column] || '';
        let valB = b[column] || '';

        if (column === 'loginTime' || column === 'time' || column === 'dueDate') {
            valA = new Date(valA).getTime() || 0;
            valB = new Date(valB).getTime() || 0;
        } else if (column === 'licenseCount' || column === 'paymentCount') {
            valA = parseInt(valA) || 0;
            valB = parseInt(valB) || 0;
        } else {
            valA = String(valA).toLowerCase();
            valB = String(valB).toLowerCase();
        }

        if (valA < valB) return direction === 'asc' ? -1 : 1;
        if (valA > valB) return direction === 'asc' ? 1 : -1;
        return 0;
    });
}

// Render Stats
function renderStats() {
    let totalLicenses = 0;
    let activeLicenses = 0;
    let totalPayments = 0;

    Object.values(accounts).forEach(acc => {
        if (acc.licenses) {
            totalLicenses += acc.licenses.length;
            activeLicenses += acc.licenses.filter(l => l.isActive).length;
        }
        if (acc.payments) totalPayments += acc.payments.length;
    });

    document.getElementById('statTotalAccounts').textContent = Object.keys(accounts).length;
    document.getElementById('statSuccessful').textContent = successfulLogins.length;
    document.getElementById('statFailed').textContent = failedLogins.length;
    document.getElementById('statTotalLicenses').textContent = totalLicenses;
    document.getElementById('statActiveLicenses').textContent = activeLicenses;
    document.getElementById('statTotalPayments').textContent = totalPayments;
}

// Get Product Counts
function getProductCounts() {
    const counts = {};
    Object.values(accounts).forEach(acc => {
        if (acc.licenses) {
            acc.licenses.forEach(lic => {
                const product = lic.product || 'Bilinmeyen';
                if (!counts[product]) counts[product] = 0;
                counts[product]++;
            });
        }
    });
    return counts;
}

// Render Product Cards
function renderProductCards() {
    const grid = document.getElementById('productCardsGrid');
    const counts = getProductCounts();
    const sortedProducts = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8);

    if (sortedProducts.length === 0) {
        grid.innerHTML = '';
        return;
    }

    grid.innerHTML = sortedProducts.map(([product, count]) => `
        <div class="product-card" data-product="${escapeHtml(product)}">
            <div class="product-name">${escapeHtml(product)}</div>
            <div class="product-count">${count}</div>
        </div>
    `).join('');

    grid.querySelectorAll('.product-card').forEach(card => {
        card.addEventListener('click', () => {
            const product = card.dataset.product;
            currentProductFilter = product;
            document.querySelector('.tab[data-tab="licenses"]').click();
            grid.querySelectorAll('.product-card').forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            renderLicenses();
        });
    });
}

// Render Product Submenu
function renderProductSubmenu() {
    const submenu = document.getElementById('productSubmenu');
    const counts = getProductCounts();
    const sortedProducts = Object.entries(counts).sort((a, b) => b[1] - a[1]);

    if (sortedProducts.length === 0) {
        submenu.innerHTML = '';
        return;
    }

    submenu.innerHTML = [
        `<div class="submenu-item ${!currentProductFilter ? 'active' : ''}" data-product="all">Tümü</div>`,
        ...sortedProducts.map(([product, count]) => `
            <div class="submenu-item ${currentProductFilter === product ? 'active' : ''}" data-product="${escapeHtml(product)}">
                ${escapeHtml(product)} (${count})
            </div>
        `)
    ].join('');

    submenu.querySelectorAll('.submenu-item').forEach(item => {
        item.addEventListener('click', () => {
            const product = item.dataset.product;
            currentProductFilter = product === 'all' ? null : product;
            submenu.querySelectorAll('.submenu-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            renderLicenses();
        });
    });
}

// Render Active Licenses
function renderActiveLicenses() {
    const tbody = document.getElementById('activeLicensesTableBody');
    tbody.innerHTML = '';

    let allLicenses = [];
    Object.values(accounts).forEach(acc => {
        if (acc.licenses) {
            acc.licenses.filter(l => l.isActive).forEach(lic => {
                allLicenses.push({
                    ...lic,
                    email: acc.email,
                    password: acc.password || getAccountPassword(acc.email)
                });
            });
        }
    });

    if (searchQuery) {
        allLicenses = allLicenses.filter(lic => matchesSearch(lic, searchQuery));
    }
    allLicenses = sortData(allLicenses, sortColumn, sortDirection);

    if (allLicenses.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><div class="empty-state-icon">⚡</div>Aktif lisans bulunamadı</td></tr>';
        return;
    }

    allLicenses.forEach(lic => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${escapeHtml(lic.email)}<button class="copy-btn" onclick="copyToClipboard('${escapeJs(lic.email)}', this)">📋</button></td>
            <td><code>${escapeHtml(lic.password)}</code><button class="copy-btn" onclick="copyToClipboard('${escapeJs(lic.password)}', this)">📋</button></td>
            <td>${escapeHtml(lic.product)}</td>
            <td><code>${escapeHtml(lic.licenseKey || '-')}</code></td>
            <td>${escapeHtml(lic.price || '-')}</td>
            <td>${escapeHtml(lic.dueDate || '-')}</td>
            <td><span class="badge badge-success" onclick="filterByStatus('${escapeJs(lic.status)}')">${escapeHtml(lic.status)}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// Render Successful Logins
function renderSuccessful() {
    const tbody = document.getElementById('successfulTableBody');
    tbody.innerHTML = '';

    let data = successfulLogins;
    if (searchQuery) data = data.filter(item => matchesSearch(item, searchQuery));
    data = sortData(data, sortColumn, sortDirection);

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state"><div class="empty-state-icon">✅</div>Henüz giriş yapan hesap yok</td></tr>';
        return;
    }

    data.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${escapeHtml(item.email)}<button class="copy-btn" onclick="copyToClipboard('${escapeJs(item.email)}', this)">📋</button></td>
            <td><code>${escapeHtml(item.password)}</code><button class="copy-btn" onclick="copyToClipboard('${escapeJs(item.password)}', this)">📋</button></td>
            <td>${formatDate(item.loginTime)}</td>
            <td>${item.licenseCount || 0}</td>
            <td>${item.paymentCount || 0}</td>
            <td><div class="action-btns"><button class="action-btn" onclick="loginAccount('${escapeJs(item.email)}', '${escapeJs(item.password)}')">🚀 Giriş</button></div></td>
        `;
        tbody.appendChild(tr);
    });
}

// Render Failed Logins
function renderFailed() {
    const tbody = document.getElementById('failedTableBody');
    tbody.innerHTML = '';

    let data = failedLogins;
    if (searchQuery) data = data.filter(item => matchesSearch(item, searchQuery));
    data = sortData(data, sortColumn, sortDirection);

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty-state"><div class="empty-state-icon">❌</div>Henüz başarısız giriş yok</td></tr>';
        return;
    }

    data.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${escapeHtml(item.email)}<button class="copy-btn" onclick="copyToClipboard('${escapeJs(item.email)}', this)">📋</button></td>
            <td><code>${escapeHtml(item.password)}</code><button class="copy-btn" onclick="copyToClipboard('${escapeJs(item.password)}', this)">📋</button></td>
            <td><span style="color: var(--danger);">${escapeHtml(item.error || 'Bilinmeyen hata')}</span></td>
            <td>${formatDate(item.time)}</td>
        `;
        tbody.appendChild(tr);
    });
}

// Render Licenses
function renderLicenses() {
    const tbody = document.getElementById('licensesTableBody');
    tbody.innerHTML = '';

    let allLicenses = [];
    Object.values(accounts).forEach(acc => {
        if (acc.licenses) {
            acc.licenses.forEach(lic => {
                allLicenses.push({
                    ...lic,
                    email: acc.email,
                    password: acc.password || getAccountPassword(acc.email)
                });
            });
        }
    });

    if (currentProductFilter) {
        allLicenses = allLicenses.filter(lic =>
            lic.product && lic.product.toLowerCase() === currentProductFilter.toLowerCase()
        );
    }
    if (searchQuery) allLicenses = allLicenses.filter(lic => matchesSearch(lic, searchQuery));
    allLicenses = sortData(allLicenses, sortColumn, sortDirection);

    if (allLicenses.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state"><div class="empty-state-icon">🔑</div>Henüz lisans verisi yok</td></tr>';
        return;
    }

    allLicenses.forEach(lic => {
        const tr = document.createElement('tr');
        const statusClass = lic.isActive ? 'badge-success' : 'badge-danger';
        tr.innerHTML = `
            <td>${escapeHtml(lic.email)}<button class="copy-btn" onclick="copyToClipboard('${escapeJs(lic.email)}', this)">📋</button></td>
            <td><code>${escapeHtml(lic.password)}</code><button class="copy-btn" onclick="copyToClipboard('${escapeJs(lic.password)}', this)">📋</button></td>
            <td>${escapeHtml(lic.product)}</td>
            <td><code>${escapeHtml(lic.licenseKey || '-')}</code></td>
            <td>${escapeHtml(lic.price || '-')}</td>
            <td>${escapeHtml(lic.billingCycle || '-')}</td>
            <td>${escapeHtml(lic.dueDate || '-')}</td>
            <td><span class="badge ${statusClass}" onclick="filterByStatus('${escapeJs(lic.status)}')">${escapeHtml(lic.status)}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// Render Payments
function renderPayments() {
    const tbody = document.getElementById('paymentsTableBody');
    tbody.innerHTML = '';

    let allPayments = [];
    Object.values(accounts).forEach(acc => {
        if (acc.payments) {
            acc.payments.forEach(pay => {
                allPayments.push({
                    ...pay,
                    email: acc.email,
                    password: acc.password || getAccountPassword(acc.email)
                });
            });
        }
    });

    if (searchQuery) allPayments = allPayments.filter(pay => matchesSearch(pay, searchQuery));
    allPayments = sortData(allPayments, sortColumn, sortDirection);

    if (allPayments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><div class="empty-state-icon">💳</div>Henüz ödeme yöntemi verisi yok</td></tr>';
        return;
    }

    allPayments.forEach(pay => {
        const tr = document.createElement('tr');
        const statusClass = pay.isActive ? 'badge-success' : 'badge-danger';
        
        let cardIcon = '💳';
        const cardType = (pay.cardType || pay.methodName || '').toLowerCase();
        if (cardType.includes('mastercard')) cardIcon = '🟠';
        else if (cardType.includes('visa')) cardIcon = '🔵';
        else if (cardType.includes('paypal')) cardIcon = '🔷';
        else if (cardType.includes('american') || cardType.includes('amex')) cardIcon = '🟡';
        else if (cardType.includes('discover')) cardIcon = '🟣';
        else if (cardType.includes('stripe')) cardIcon = '⚡';
        else if (cardType.includes('bank') || cardType.includes('havale')) cardIcon = '🏦';
        else if (cardType.includes('crypto') || cardType.includes('bitcoin')) cardIcon = '₿';
        else if (cardType.includes('apple')) cardIcon = '🍎';
        else if (cardType.includes('google')) cardIcon = '🔍';
        
        tr.innerHTML = `
            <td>${escapeHtml(pay.email)}<button class="copy-btn" onclick="copyToClipboard('${escapeJs(pay.email)}', this)">📋</button></td>
            <td><code>${escapeHtml(pay.password)}</code><button class="copy-btn" onclick="copyToClipboard('${escapeJs(pay.password)}', this)">📋</button></td>
            <td>${cardIcon} ${escapeHtml(pay.methodName)}</td>
            <td>${escapeHtml(pay.cardType || '-')}</td>
            <td>${escapeHtml(pay.description || '-')}</td>
            <td><span class="badge ${statusClass}">${escapeHtml(pay.status)}</span></td>
            <td>${pay.isDefault ? '✅' : '-'}</td>
        `;
        tbody.appendChild(tr);
    });
}

// Filter by Status
function filterByStatus(status) {
    document.getElementById('searchBox').value = status;
    searchQuery = status.toLowerCase();
    renderAll();
}

// Bot Functions
function showBotModal() {
    document.getElementById('botModal').classList.add('active');
}

function hideBotModal() {
    document.getElementById('botModal').classList.remove('active');
}

function startBot() {
    const input = document.getElementById('accountListInput').value.trim();
    const delay = parseInt(document.getElementById('botDelay').value) || 6000;

    if (!input) {
        showNotification('Lütfen hesap listesi girin!', 'error');
        return;
    }

    const accountList = input.split('\n')
        .map(line => line.trim())
        .filter(line => line.includes(':'));

    if (accountList.length === 0) {
        showNotification('Geçerli hesap bulunamadı!', 'error');
        return;
    }

    botStartTime = Date.now();
    botProcessedCount = 0;

    chrome.runtime.sendMessage({
        type: 'START_BOT',
        accounts: accountList,
        delay: delay,
        skipExisting: isSkippingExisting
    });

    hideBotModal();
    
    // Bot panelini göster ve sabit tut
    const botPanel = document.getElementById('botPanel');
    botPanel.classList.add('active');
    botPanel.style.display = 'block';
    
    document.getElementById('botLog').innerHTML = '<div>Bot başlatılıyor...</div>';
    startElapsedTimer();
}

function startElapsedTimer() {
    const elapsedEl = document.getElementById('botElapsed');
    const timer = setInterval(() => {
        if (!botStartTime) {
            clearInterval(timer);
            return;
        }
        const elapsed = Math.floor((Date.now() - botStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
        const seconds = (elapsed % 60).toString().padStart(2, '0');
        elapsedEl.textContent = `${minutes}:${seconds}`;
    }, 1000);
}

function stopBot() {
    chrome.runtime.sendMessage({ type: 'STOP_BOT' });
    botStartTime = null;
    hideCaptchaPanel();
    showNotification('Bot durduruldu!', 'success');
}

function pauseBot() {
    chrome.runtime.sendMessage({ type: 'PAUSE_BOT' });
    document.getElementById('btnPause').style.display = 'none';
    document.getElementById('btnResume').style.display = 'inline-flex';
    showNotification('Bot duraklatıldı!', 'success');
}

function resumeBot() {
    chrome.runtime.sendMessage({ type: 'RESUME_BOT' });
    document.getElementById('btnPause').style.display = 'inline-flex';
    document.getElementById('btnResume').style.display = 'none';
    showNotification('Bot devam ediyor!', 'success');
}

function restartBot() {
    if (confirm('Bot yeniden başlatılacak. Emin misiniz?')) {
        chrome.runtime.sendMessage({ type: 'RESTART_BOT' });
        document.getElementById('botLog').innerHTML = '<div>Bot yeniden başlatılıyor...</div>';
        botStartTime = Date.now();
        startElapsedTimer();
        hideCaptchaPanel();
        showNotification('Bot yeniden başlatıldı!', 'success');
    }
}

function updateBotStatus(msg) {
    const progress = msg.total > 0 ? (msg.current / msg.total) * 100 : 0;
    document.getElementById('progressFill').style.width = progress + '%';
    document.getElementById('progressText').textContent = `${msg.current} / ${msg.total} hesap`;
    document.getElementById('currentAccount').textContent = msg.email || '-';

    botProcessedCount = msg.current;
    document.getElementById('botRemaining').textContent = msg.total - msg.current;

    if (botStartTime && msg.current > 0) {
        const elapsedMinutes = (Date.now() - botStartTime) / 60000;
        const speed = elapsedMinutes > 0 ? (msg.current / elapsedMinutes).toFixed(1) : 0;
        document.getElementById('botSpeed').textContent = speed;

        const remaining = msg.total - msg.current;
        const etaMinutes = speed > 0 ? Math.ceil(remaining / speed) : 0;
        const etaHours = Math.floor(etaMinutes / 60);
        const etaMins = etaMinutes % 60;

        if (etaHours > 0) {
            document.getElementById('etaTimer').textContent = `Tahmini: ${etaHours}s ${etaMins}d`;
        } else {
            document.getElementById('etaTimer').textContent = `Tahmini: ${etaMins}d`;
        }
    }
    
    // Cloudflare bekleniyor durumu
    if (msg.step && msg.step.includes('Robot')) {
        document.getElementById('currentAccount').innerHTML = `<span style="color: var(--warning);">🔒 ${msg.email}</span>`;
    }
}

function addBotLog(message) {
    const log = document.getElementById('botLog');
    const time = new Date().toLocaleTimeString('tr-TR');
    const div = document.createElement('div');
    
    let styledMessage = message;
    if (message.includes('CLOUDFLARE') || message.includes('Robot')) {
        div.style.color = 'var(--warning)';
        div.style.fontWeight = 'bold';
    } else if (message.includes('✅')) {
        div.style.color = 'var(--neon-green)';
    } else if (message.includes('❌')) {
        div.style.color = 'var(--danger)';
    } else if (message.includes('💳')) {
        div.style.color = '#00ccff';
    }
    
    div.textContent = `[${time}] ${message}`;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
}

function botFinished(msg) {
    document.getElementById('currentAccount').textContent = 'Tamamlandı';
    document.getElementById('etaTimer').textContent = 'Tahmini: Tamamlandı';
    botStartTime = null;
    hideCaptchaPanel();
    showNotification(`Bot tamamlandı! ${msg.successful} başarılı, ${msg.failed} başarısız${msg.skipped ? `, ${msg.skipped} atlanmış` : ''}`, 'success');
    loadData();
}

// Excel Export
function exportToExcel() {
    let csvContent = '\uFEFF';
    csvContent += 'WHMCS ELITE CRM PRO - DETAYLI RAPOR\n';
    csvContent += `Olusturma Tarihi: ${new Date().toLocaleString('tr-TR')}\n\n`;

    csvContent += '=== AKTIF LISANSLAR ===\n';
    csvContent += 'Hesap,Sifre,Urun,Lisans Key,Fiyat,Son Tarih,Durum\n';
    Object.values(accounts).forEach(acc => {
        if (acc.licenses) {
            acc.licenses.filter(l => l.isActive).forEach(lic => {
                csvContent += `"${acc.email}","${acc.password || ''}","${lic.product}","${lic.licenseKey || ''}","${lic.price || ''}","${lic.dueDate || ''}","${lic.status}"\n`;
            });
        }
    });

    csvContent += '\n=== GIRIS YAPAN HESAPLAR ===\n';
    csvContent += 'E-Posta,Sifre,Giris Zamani,Lisans Sayisi,Odeme Yontemi Sayisi\n';
    successfulLogins.forEach(item => {
        csvContent += `"${item.email}","${item.password}","${formatDate(item.loginTime)}",${item.licenseCount || 0},${item.paymentCount || 0}\n`;
    });

    csvContent += '\n=== GIRIS YAPAMAYAN HESAPLAR ===\n';
    csvContent += 'E-Posta,Sifre,Hata,Zaman\n';
    failedLogins.forEach(item => {
        csvContent += `"${item.email}","${item.password}","${item.error || 'Bilinmeyen hata'}","${formatDate(item.time)}"\n`;
    });

    csvContent += '\n=== TUM LISANSLAR ===\n';
    csvContent += 'Hesap,Sifre,Urun,Lisans Key,Fiyat,Fatura Dongusu,Son Tarih,Durum\n';
    Object.values(accounts).forEach(acc => {
        if (acc.licenses) {
            acc.licenses.forEach(lic => {
                csvContent += `"${acc.email}","${acc.password || ''}","${lic.product}","${lic.licenseKey || ''}","${lic.price || ''}","${lic.billingCycle || ''}","${lic.dueDate || ''}","${lic.status}"\n`;
            });
        }
    });

    csvContent += '\n=== ODEME YONTEMLERI (DETAYLI) ===\n';
    csvContent += 'Hesap,Sifre,Odeme Yontemi,Kart Tipi,Aciklama,Kart No (Son 4),SKT,Durum,Varsayilan\n';
    Object.values(accounts).forEach(acc => {
        if (acc.payments) {
            acc.payments.forEach(pay => {
                csvContent += `"${acc.email}","${acc.password || ''}","${pay.methodName}","${pay.cardType || ''}","${pay.description || ''}","${pay.cardLast4 || ''}","${pay.expiryDate || ''}","${pay.status}","${pay.isDefault ? 'Evet' : 'Hayir'}"\n`;
            });
        }
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const date = new Date().toISOString().split('T')[0];
    link.href = URL.createObjectURL(blob);
    link.download = `WHMCS_Rapor_${date}.csv`;
    link.click();

    showNotification('Excel dosyasi indirildi!', 'success');
}

// JSON Export
function exportToJson() {
    const data = {
        exportDate: new Date().toISOString(),
        accounts,
        successfulLogins,
        failedLogins
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');

    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');

    link.href = URL.createObjectURL(blob);
    link.download = `WHMCS_Yedek_${dateStr}_${timeStr}.json`;
    link.click();

    showNotification('JSON yedek indirildi!', 'success');
}

// Import Functions
function handleTxtImport(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        document.getElementById('accountListInput').value = event.target.result;
        showBotModal();
    };
    reader.readAsText(file);
    e.target.value = '';
}

function handleJsonImport(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = JSON.parse(event.target.result);
            if (confirm('Mevcut verilerin uzerine yazilsin mi?')) {
                accounts = data.accounts || {};
                successfulLogins = data.successfulLogins || [];
                failedLogins = data.failedLogins || [];

                chrome.storage.local.set({
                    accounts,
                    successfulLogins,
                    failedLogins
                }, () => {
                    loadData();
                    showNotification('Veriler yuklendi!', 'success');
                });
            }
        } catch (err) {
            showNotification('Gecersiz JSON dosyasi!', 'error');
        }
    };
    reader.readAsText(file);
    e.target.value = '';
}

// Reset All
function resetAll() {
    if (confirm('⚠️ TUM VERILER SILINECEK!\n\nBu islem geri alinamaz. Emin misiniz?')) {
        accounts = {};
        successfulLogins = [];
        failedLogins = [];

        chrome.storage.local.set({
            accounts: {},
            successfulLogins: [],
            failedLogins: []
        }, () => {
            loadData();
            showNotification('Tum veriler temizlendi!', 'success');
        });
    }
}

// Utility Functions
function copyToClipboard(text, btn = null) {
    if (!text || text === '-') return;

    navigator.clipboard.writeText(text).then(() => {
        showNotification('Kopyalandi!', 'success');

        if (btn) {
            const originalText = btn.textContent;
            btn.textContent = '✓';
            btn.classList.add('copied');
            setTimeout(() => {
                btn.textContent = originalText;
                btn.classList.remove('copied');
            }, 1500);
        }
    });
}

function loginAccount(email, password) {
    chrome.runtime.sendMessage({
        type: 'SINGLE_LOGIN',
        email,
        password
    });
    showNotification('Giris yapiliyor...', 'success');
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('tr-TR');
}

function showNotification(message, type = 'success') {
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();

    const notif = document.createElement('div');
    notif.className = 'notification';
    notif.textContent = message;

    if (type === 'error') {
        notif.style.borderColor = 'var(--danger)';
        notif.style.boxShadow = '0 0 20px rgba(255, 51, 51, 0.3)';
    }

    document.body.appendChild(notif);

    setTimeout(() => {
        notif.remove();
    }, 3000);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function escapeJs(text) {
    if (!text) return '';
    return text.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"');
}

// Storage listener
chrome.storage.onChanged.addListener((changes) => {
    if (changes.accounts || changes.successfulLogins || changes.failedLogins) {
        loadData();

        if (changes.accounts) {
            const oldAccounts = changes.accounts.oldValue || {};
            const newAccounts = changes.accounts.newValue || {};

            let newActiveLicense = false;
            Object.keys(newAccounts).forEach(email => {
                const oldLicenses = oldAccounts[email]?.licenses || [];
                const newLicenses = newAccounts[email]?.licenses || [];

                const oldActiveCount = oldLicenses.filter(l => l.isActive).length;
                const newActiveCount = newLicenses.filter(l => l.isActive).length;

                if (newActiveCount > oldActiveCount) {
                    newActiveLicense = true;
                }
            });

            if (newActiveLicense) {
                playSuccessSound();
            }
        }
    }
});
